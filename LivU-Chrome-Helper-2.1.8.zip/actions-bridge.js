(() => {
  "use strict";
  if (window.__livuRowActionsBridge) return;
  window.__livuRowActionsBridge = true;

  const profiles = new Map();
  const albums = new Map();
  const stores = new WeakMap();
  const definitions = new WeakMap();
  const busy = new Set();
  let hoverTimer;
  let hovering;
  let overRow = false;
  let requests = 0;
  let albumRequests = 0;
  let nativeRequire;
  let lastCall = -Infinity;
  let timer;
  let ageTimer;
  let accountScope = "uninitialized";
  let accountEpoch = 0;
  let videoCallKey = "";
  let videoCallFrameSeen = false;
  let videoCallEpoch = 0;

  function idOf(item) {
    const id = Number(item?.friendId ?? item?.id);
    return Number.isSafeInteger(id) && id > 0 ? id : null;
  }
  function ageOf(item) {
    if (!item || typeof item !== "object") return null;
    const raw = typeof item.age === "number" || typeof item.age === "string" ? item.age : null;
    const age = typeof raw === "number" ? raw : raw && /^\d{1,3}$/.test(raw) ? Number(raw) : NaN;
    if (Number.isSafeInteger(age) && age >= 18 && age <= 120) return age;
    for (const key of ["birthday", "birthDay", "birthdate", "birthDate"]) {
      const value = item[key];
      if (value instanceof Date) {
        const derived = ageAt(value);
        if (derived != null) return derived;
      } else if (typeof value === "number" || typeof value === "string") {
        const derived = birthdayAge(value);
        if (derived != null) return derived;
      }
    }
    return null;
  }
  function ageAt(birthday) {
    const now = new Date();
    if (!Number.isFinite(birthday.getTime()) || birthday.getTime() > now.getTime()) return null;
    let age = now.getFullYear() - birthday.getFullYear();
    if (now.getMonth() < birthday.getMonth() ||
        (now.getMonth() === birthday.getMonth() && now.getDate() < birthday.getDate())) age--;
    return age >= 18 && age <= 120 ? age : null;
  }
  function birthdayAge(value) {
    const now = new Date(); let date = null;
    if (value === 0 || value === "0" || value == null) return null;
    if (typeof value === "number" && Number.isFinite(value)) {
      if (Number.isInteger(value) && value >= 19000101 && value <= 20991231) {
        const text = String(value), year = Number(text.slice(0, 4)), month = Number(text.slice(4, 6)), day = Number(text.slice(6, 8));
        const parsed = new Date(year, month - 1, day);
        if (parsed.getFullYear() === year && parsed.getMonth() === month - 1 && parsed.getDate() === day) date = parsed;
      } else {
        // Livu's public profile detail uses birthday in milliseconds, including pre-1970 dates.
        if (value <= now.getTime()) date = new Date(value);
      }
    } else if (typeof value === "string") {
      const text = value.trim(); let match = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(text);
      if (!match) match = /^(\d{4})(\d{2})(\d{2})$/.exec(text);
      if (match) {
        const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]), parsed = new Date(year, month - 1, day);
        if (parsed.getFullYear() === year && parsed.getMonth() === month - 1 && parsed.getDate() === day) date = parsed;
      } else if (/^-?\d{10,13}$/.test(text)) {
        const stamp = Number(text);
        if (stamp <= now.getTime()) date = new Date(stamp);
      }
    }
    return date ? ageAt(date) : null;
  }
  function setAttr(element, key, value) {
    if (value == null) { if (element.hasAttribute(key)) element.removeAttribute(key); }
    else if (element.getAttribute(key) !== String(value)) element.setAttribute(key, String(value));
  }
  function accountInfo() {
    const app = findStore()?.state?.app;
    if (!app) return { known: false, id: null, scope: accountScope };
    if (app.isLogin === false) return { known: true, id: null, scope: "signed-out" };
    const id = String(app.userInfo?.id ?? "");
    return /^\d{1,16}$/.test(id) && Number(id) > 0
      ? { known: true, id, scope: `id:${id}` }
      : { known: true, id: null, scope: "unknown" };
  }
  function observeAccount() {
    const info = accountInfo();
    if (info.known && info.scope !== accountScope) {
      accountScope = info.scope;
      accountEpoch++;
      profiles.clear(); albums.clear();
      for (const row of document.querySelectorAll(".friend-list .ocell[data-lff-preview], .im-list .ocell[data-lff-preview], .im-bar .cur-msg-list > li")) {
        row.removeAttribute("data-lff-preview");
        if (row.matches(".im-bar .cur-msg-list > li")) row.removeAttribute("data-lff-user-id");
      }
    }
    return info;
  }
  function visible(element) {
    return element?.isConnected && !document.hidden && element.getBoundingClientRect().width > 0 &&
      element.getBoundingClientRect().height > 0 && getComputedStyle(element).visibility !== "hidden";
  }
  function visibleCallElement(element) {
    if (!element?.isConnected) return false;
    const style = getComputedStyle(element), rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity) > 0.01 &&
      rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 && rect.left < innerWidth && rect.top < innerHeight;
  }
  function playingVideoFrame(shell) {
    // Livu initially plays the remote track in #chat1v1-mainVideo and the
    // local preview in #chat1v1-miniVideo; don't start from self-preview alone.
    const surface = shell.querySelector("#chat1v1-mainVideo");
    if (!visibleCallElement(surface)) return false;
    for (const video of surface.querySelectorAll("video")) {
      if (visibleCallElement(video) && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA &&
          video.videoWidth > 0 && video.videoHeight > 0 && !video.paused && !video.ended) return true;
    }
    return false;
  }
  function clearVideoCallSignal() {
    videoCallKey = "";
    videoCallFrameSeen = false;
    setAttr(document.documentElement, "data-lff-video-chat-active", null);
    setAttr(document.documentElement, "data-lff-video-chat-session", null);
  }
  function syncVideoCallSignal(store) {
    const app = store?.state?.app, agora = store?.state?.agora;
    const shell = document.querySelector(".base-video-chat.video-chat");
    if (!app || !agora || !visibleCallElement(shell)) return clearVideoCallSignal();

    const peerId = value => {
      if (typeof value === "number") return Number.isSafeInteger(value) && value > 0 ? String(value) : "";
      if (typeof value !== "string") return "";
      const text = value.trim();
      return /^[A-Za-z0-9_.:-]{1,128}$/.test(text) ? text : "";
    };
    const roomId = peerId(agora.curRoomNum);
    const remoteId = peerId(agora.bizData?.remoteUserInfo?.id);
    const match = agora.matchCallData || {};
    const matchRoom = peerId(match.ident);
    const frame = playingVideoFrame(shell);
    const normalVideo = app.showVideoPop === true && roomId && remoteId && peerId(agora.curCallRole);
    const matchedVideo = app.show1v1Pop === true && Number(match.callStatus) === 1 && matchRoom;
    const callKey = normalVideo ? `video:${roomId}:${remoteId}`
      : matchedVideo ? `match:${matchRoom}:${peerId(match.id) || "peer"}` : "";
    if (!callKey) return clearVideoCallSignal();
    if (callKey !== videoCallKey) {
      videoCallKey = callKey;
      videoCallFrameSeen = false;
      videoCallEpoch++;
    }
    // Livu publishes the remote track into one of these native video surfaces.
    // Once a frame has played, keep the call eligible through temporary buffering.
    if (frame) videoCallFrameSeen = true;
    const active = videoCallFrameSeen && document.visibilityState === "visible" && !document.hidden;
    setAttr(document.documentElement, "data-lff-video-chat-active", active ? "true" : null);
    setAttr(document.documentElement, "data-lff-video-chat-session", active ? String(videoCallEpoch) : null);
  }
  function primaryVM() {
    return document.querySelector(".mb-nav-panel")?.__vue__;
  }
  function friendsVM() {
    for (const list of document.querySelectorAll(".friend-list")) {
      if (!list.closest(".im-online, .im-block") && Array.isArray(list.__vue__?.remindFriend)) return list.__vue__;
    }
    return null;
  }
  function recordFor(row) {
    if (!(row instanceof Element) || !row.isConnected) return null;
    let owner, item, kind;
    if (row.matches(".im-bar .cur-msg-list > li")) {
      owner = row.closest(".im-bar").__vue__;
      const rows = Array.from(row.parentElement.children).filter(el => el.matches("li"));
      const items = owner?.unReadUserList;
      if (!Array.isArray(items) || items.length !== rows.length) return null;
      item = items[rows.indexOf(row)]; kind = "compact";
      // The keyed list has no DOM UID/name. Verify the native item against its
      // rendered avatar as well as its position before publishing an identity.
      const avatarVM = row.querySelector(".fitImg-box")?.__vue__;
      const avatar = avatarVM?.$props?.headImg ?? avatarVM?.headImg ?? row.querySelector(".avatar-wrap img")?.getAttribute("src");
      if (!photoURL(item?.headImg) || photoURL(avatar) !== photoURL(item.headImg)) return null;
    } else if (row.closest(".im-online")) {
      owner = row.closest(".im-online").__vue__;
      const rows = Array.from(row.parentElement.children).filter(el => el.matches(".ocell"));
      item = owner?.onlineList?.[rows.indexOf(row)]; kind = "bell";
    } else if (row.closest(".im-list")) {
      owner = row.__vue__;
      item = owner?.itemData; kind = "message";
      if (!item) {
        owner = row.closest(".im-list").__vue__;
        item = owner?.currChatUsers?.find(item => idOf(item) === Number(row.getAttribute("data-id")));
      }
    } else {
      const list = row.closest(".friend-list");
      if (!list || list.closest(".im-block, .im-say-hi")) return null;
      owner = list.__vue__; kind = "friend";
      const id = Number(row.getAttribute("data-id"));
      item = (owner?.remindFriend || []).find(item => idOf(item) === id)
        || (owner?.friendList || []).find(item => idOf(item) === id);
    }
    const id = idOf(item);
    if (!id || !owner) return null;
    if (kind !== "compact" && row.querySelector(".name")?.textContent.trim() !== String(item.userName ?? "").trim()) return null;
    if (kind !== "bell" && kind !== "compact" && Number(row.getAttribute("data-id")) !== id) return null;
    return { row, owner, item, id, kind };
  }
  function syncCompactRows() {
    for (const row of document.querySelectorAll(".im-bar .cur-msg-list > li")) {
      const record = recordFor(row), id = record ? String(record.id) : null;
      if (row.getAttribute("data-lff-user-id") !== id) {
        row.removeAttribute("data-lff-preview");
        setAttr(row, "data-lff-user-id", id);
      }
    }
  }
  function renameRecordFor(host) {
    if (!host?.matches("livu-profile-preview") || host.getAttribute("data-lff-rename-active") !== "true" ||
        host.getAttribute("data-lff-rename-valid") !== "true" || !host.getAttribute("data-lff-rename-token")) return null;
    const info = observeAccount();
    const accountId = String(info.id ?? "");
    const id = Number(host.getAttribute("data-lff-rename-id"));
    const kind = host.getAttribute("data-lff-rename-kind");
    if (!Number.isSafeInteger(id) || id <= 0 || host.getAttribute("data-lff-target") !== String(id) ||
        host.getAttribute("data-lff-rename-account") !== accountId || !new Set(["person", "conversation"]).has(kind)) return null;
    const selector = kind === "conversation" ? ".im-list .ocell.user-cell" : ".friend-list .ocell";
    for (const row of document.querySelectorAll(selector)) {
      // Filter by the row's stable DOM UID before recordFor performs its native-array lookup.
      // A large list should cost one native lookup for the row being edited, not one per row.
      if (kind === "conversation" && Number(row.getAttribute("data-id")) !== id) continue;
      if (kind === "person") {
        const uid = row.closest(".im-online") ? Number(row.getAttribute("data-lff-user-id")) : Number(row.getAttribute("data-id"));
        if (uid !== id) continue;
      }
      const record = recordFor(row);
      const sameKind = kind === "conversation" ? record?.kind === "message" : ["friend", "bell"].includes(record?.kind);
      if (record?.id === id && sameKind) return record;
    }
    return null;
  }
  function publishAge(row, id, item) {
    if (!row?.isConnected || !id || row.querySelector(".name")?.textContent.trim() !== String(item?.userName ?? "").trim()) return;
    const cachedAge = profiles.get(id)?.public?.age;
    const age = ageOf(item) ?? (Number.isSafeInteger(Number(cachedAge)) ? Number(cachedAge) : null);
    setAttr(row, "data-lff-age", age != null && age >= 18 && age <= 120 ? age : null);
  }
  function scheduleAges() {
    if (ageTimer != null) return;
    ageTimer = setTimeout(() => { ageTimer = null; syncAges(); }, 120);
  }
  function syncAges() {
    for (const list of document.querySelectorAll(".friend-list")) {
      const bell = list.closest(".im-online");
      if (bell) {
        const vm = bell.__vue__, items = vm?.onlineList;
        const rows = Array.from(list.children).filter(row => row.matches(".ocell"));
        if (!Array.isArray(items) || rows.length !== items.length) continue;
        for (let index = 0; index < rows.length; index++) publishAge(rows[index], idOf(items[index]), items[index]);
        continue;
      }
      const vm = list.__vue__;
      if (!vm) continue;
      const byId = new Map();
      for (const group of [vm.remindFriend, vm.friendList]) if (Array.isArray(group)) {
        for (const item of group) { const id = idOf(item); if (id) byId.set(id, item); }
      }
      for (const row of list.querySelectorAll(".flist-box .ocell[data-id]")) {
        const id = Number(row.getAttribute("data-id")), item = byId.get(id);
        if (item) publishAge(row, id, item);
      }
    }
    for (const list of document.querySelectorAll(".im-list")) {
      const vm = list.__vue__;
      if (!vm) continue;
      const byId = new Map();
      for (const group of [vm.currChatUsers, vm.chatUsersTemp]) if (Array.isArray(group)) {
        for (const item of group) { const id = idOf(item); if (id) byId.set(id, item); }
      }
      for (const row of list.querySelectorAll(".ocell.user-cell[data-id]")) {
        const id = Number(row.getAttribute("data-id")), item = byId.get(id) || row.__vue__?.itemData;
        if (item && idOf(item) === id) publishAge(row, id, item);
      }
    }
  }
  function optionsOf(component) { return component?.options || component; }
  function nativeOptions(owner, name) {
    const root = owner.$root || owner;
    let cache = definitions.get(root);
    if (!cache) { cache = new Map(); definitions.set(root, cache); }
    if (cache.has(name)) return cache.get(name);
    const seen = new Set();
    const queue = [];
    for (let vm = owner, n = 0; vm && n < 8; vm = vm.$parent, n++) queue.push(vm.$options);
    queue.push(root.$options);
    for (const element of document.querySelectorAll(".mb-nav-panel, .im-chat, .im-bar")) queue.push(element.__vue__?.$options);
    while (queue.length && seen.size < 180) {
      const options = optionsOf(queue.shift());
      if (!options || seen.has(options)) continue;
      seen.add(options);
      if (options.name === name && options.methods) { cache.set(name, options); return options; }
      for (const child of Object.values(options.components || {})) queue.push(child);
    }
    // Missing lazy components may become available later; don't cache absence.
    return null;
  }
  function contextFor(owner, fields) {
    const context = Object.create(owner);
    for (const [key, value] of Object.entries(fields)) Object.defineProperty(context, key, { value, writable: true, configurable: true });
    return context;
  }
  function publicProfile(detail) {
    const result = {};
    for (const key of ["userName", "headImg", "description", "introduce", "signature"]) {
      if (typeof detail[key] === "string" || typeof detail[key] === "number") result[key] = String(detail[key]).slice(0, key === "headImg" ? 1500 : 500);
    }
    const age = ageOf(detail);
    if (typeof detail.countryName === "string") result.country = detail.countryName.replace(/\s+/g, " ").trim().slice(0, 80);
    if (age != null) result.age = age;
    result.favorite = Boolean(detail.stick);
    return result;
  }
  function photoURL(value) {
    if (typeof value !== "string" || !value.trim() || value.length > 1500) return null;
    try {
      const url = new URL(value, location.href);
      return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  }
  function nativePhotoLoader() {
    if (!nativeRequire) {
      const chunks = window.webpackJsonp;
      if (!Array.isArray(chunks) || chunks.push === Array.prototype.push) return null;
      // Read the already-loaded album function from Livu's own webpack 4 runtime.
      // The temporary adapter loads no chunks and is removed immediately.
      const key = `__livuFiltersPhotos_${crypto.randomUUID()}`;
      const adapter = [[], { [key](module, exports, require) { nativeRequire = require; } }, [[key]]];
      try { chunks.push(adapter); } catch { return null; }
      finally {
        if (nativeRequire?.m) delete nativeRequire.m[key];
        if (nativeRequire?.c) delete nativeRequire.c[key];
        const index = chunks.indexOf(adapter);
        if (index >= 0) chunks.splice(index, 1);
      }
    }
    // Public app module 310c.g: getUserPics({searchUserId}), returning data.picList[].pic.
    const loader = nativeRequire?.c?.["310c"]?.exports?.g;
    return typeof loader === "function" ? loader : null;
  }
  function publishAlbum(record) {
    const entry = profiles.get(record.id);
    if (entry) publish(record, entry);
  }
  function getPhotos(record) {
    let album = albums.get(record.id);
    const lifetime = album?.state === "unavailable" ? 30000 : 300000;
    if (album && (album.state === "loading" || Date.now() - album.time < lifetime)) return;
    if (albumRequests >= 2) return;
    const loader = nativePhotoLoader();
    album = { state: loader ? "loading" : "unavailable", urls: [], time: Date.now() };
    albums.delete(record.id); albums.set(record.id, album);
    if (albums.size > 30) albums.delete(albums.keys().next().value);
    if (!loader) return;
    albumRequests++;
    const requestEpoch = accountEpoch;
    let finished = false;
    const timeout = setTimeout(() => finish(null), 10000);
    function finish(response) {
      if (finished) return;
      finished = true; clearTimeout(timeout); albumRequests--;
      observeAccount();
      if (requestEpoch !== accountEpoch) return;
      const list = response?.data?.picList;
      album.state = Array.isArray(list) ? "ready" : "unavailable";
      album.urls = Array.isArray(list) ? [...new Set(list.slice(0, 100).map(item => photoURL(item?.pic)).filter(Boolean))] : [];
      album.time = Date.now(); publishAlbum(record);
    }
    try { Promise.resolve(loader({ searchUserId: record.id })).then(finish, () => finish(null)); }
    catch { finish(null); }
  }
  function publish(record, entry) {
    if (!record.row.isConnected || recordFor(record.row)?.id !== record.id) return;
    const age = entry.public.age ?? ageOf(record.item);
    setAttr(record.row, "data-lff-age", age != null && age >= 18 && age <= 120 ? age : null);
    const album = albums.get(record.id);
    let profileUrl = null;
    try { profileUrl = profileRoute(record); } catch { /* Keep unavailable links disabled. */ }
    setAttr(record.row, "data-lff-preview", JSON.stringify({ state: entry.state, ...entry.public,
      profileUrl,
      photosState: album?.state || "idle", photos: album?.urls || [],
      favoriteAction: entry.state === "ready" && entry.native?.relation === 2 && Boolean(nativeOptions(record.owner, "UserMenu")?.methods?.addFav),
      renameAction: record.kind !== "compact" && entry.state === "ready" && entry.native?.relation === 2 && Boolean(nativeOptions(record.owner, "UserMenu")?.methods?.changeName),
      callAction: entry.state === "ready" && Boolean(nativeOptions(record.owner, "DialogBox")?.methods?.sendCall && record.owner.$callMgr) }));
  }
  function getProfile(record) {
    observeAccount();
    getPhotos(record);
    let entry = profiles.get(record.id);
    if (entry && (entry.state === "loading" || Date.now() - entry.time < 60000)) { publish(record, entry); return; }
    const method = nativeOptions(record.owner, "QuickMenu")?.methods?.getFriendInfo;
    if (typeof method !== "function" || requests >= 2) {
      publish(record, { state: "unavailable", public: publicProfile(record.item) }); return;
    }
    entry = { state: "loading", time: Date.now(), public: publicProfile(record.item), native: null };
    profiles.delete(record.id); profiles.set(record.id, entry);
    if (profiles.size > 30) profiles.delete(profiles.keys().next().value);
    publish(record, entry); requests++;
    const requestEpoch = accountEpoch;
    let finished = false;
    const timeout = setTimeout(() => finish(null), 10000);
    function finish(detail) {
      if (finished) return;
      finished = true; clearTimeout(timeout); requests--;
      observeAccount();
      if (requestEpoch !== accountEpoch) return;
      if (idOf(detail) === record.id) {
        entry.state = "ready"; entry.native = detail; entry.public = { ...publicProfile(record.item), ...publicProfile(detail) };
      } else entry.state = "unavailable";
      entry.time = Date.now(); publish(record, entry);
    }
    const context = contextFor(record.owner, { friendInfo: { friendId: record.id }, isFav: Boolean(record.item.stick) });
    let detail = {};
    Object.defineProperty(context, "friendDetail", { get: () => detail, set: value => { detail = value; finish(value); } });
    try {
      const result = method.call(context);
      if (result?.catch) result.catch(() => finish(null));
    } catch { finish(null); }
  }
  function hover(event) {
    if (!event.isTrusted || !(event.target instanceof Element)) return;
    observeAccount();
    if (event.target.closest("livu-row-actions, livu-profile-preview")) return;
    const row = event.target.closest(".friend-list .ocell, .im-list .ocell, .im-bar .cur-msg-list > li");
    if (!row) { clearTimeout(hoverTimer); overRow = false; return; }
    if (row === hovering && overRow) return;
    clearTimeout(hoverTimer); hovering = row; overRow = true;
    const record = recordFor(row);
    if (row.matches(".im-bar .cur-msg-list > li")) {
      syncCompactRows();
      if (record) publish(record, { state: "loading", public: publicProfile(record.item) });
    }
    if (record) publishAge(row, record.id, record.item);
    if (record && visible(row)) hoverTimer = setTimeout(() => {
      if (hovering === row && visible(row) && recordFor(row)?.item === record.item) getProfile(record);
    }, 350);
  }
  function result(host, state, link) {
    setAttr(host, "data-lff-result", null);
    if (link) setAttr(host, "data-lff-link", link);
    setAttr(host, "data-lff-result", state);
  }
  function profileRoute(record) {
    const vm = routeVM(record);
    const method = vm?.$options?.methods?.jumpToProfile;
    if (typeof method !== "function" || !vm.$router?.resolve) return null;
    let route;
    // Let Livu encode its own profile ID, while capturing rather than navigating.
    const context = contextFor(vm, { $store: { commit() {} }, $router: { push(value) { route = value; } }, isMobile: false, friendtab: false });
    method.call(context, record.id);
    if (route?.name !== "FriendPage") return null;
    const url = new URL(vm.$router.resolve(route).href, location.origin);
    return url.origin === location.origin && /\/profile\/[^/]+$/.test(url.pathname) ? url.href : null;
  }
  function openProfile(record) {
    const vm = routeVM(record);
    if (typeof vm?.jumpToProfile !== "function") return false;
    if (record.kind === "bell") record.owner.cancelPanel();
    vm.jumpToProfile(record.id); return true;
  }
  function routeVM(record) {
    if (record.kind !== "bell" && record.kind !== "compact") return record.owner;
    return [record.owner, friendsVM(), ...Array.from(document.querySelectorAll(".im-list .ocell.user-cell"), row => row.__vue__)]
      .find(vm => typeof vm?.$options?.methods?.jumpToProfile === "function" && vm.$router?.resolve);
  }
  function updateEntries(id, key, value) {
    const seen = new Set();
    for (const element of document.querySelectorAll(".friend-list, .im-list, .im-online, .im-chat")) {
      const vm = element.__vue__;
      if (!vm || seen.has(vm)) continue;
      seen.add(vm);
      const groups = [vm.remindFriend, vm.friendList, vm.onlineList, vm.currChatUsers, vm.chatUsersTemp,
        vm.itemData ? [vm.itemData] : [], vm.friendDetail ? [vm.friendDetail] : []].filter(Array.isArray);
      for (const group of groups) for (const item of group) {
        if (idOf(item) === id && typeof vm.$set === "function") vm.$set(item, key, value);
      }
      if (key === "stick" && Array.isArray(vm.remindFriend) && Array.isArray(vm.friendList)) {
        const from = value ? vm.friendList : vm.remindFriend, to = value ? vm.remindFriend : vm.friendList;
        const index = from.findIndex(item => idOf(item) === id);
        if (index >= 0) {
          const [item] = from.splice(index, 1);
          if (!to.some(item => idOf(item) === id)) to.push(item);
        }
      }
      if (vm.friendId === id && key === "stick" && typeof vm.changeFriendStick === "function") vm.changeFriendStick(value);
      if (vm.friendId === id && key === "userName" && typeof vm.changeUserName === "function") vm.changeUserName(value);
    }
    const entry = profiles.get(id);
    if (entry?.native) { entry.native[key] = value; entry.public = publicProfile(entry.native); entry.time = Date.now(); }
    schedule();
  }
  function changeFriend(record, action, value, host) {
    const requestAccount = action === "rename" ? observeAccount() : null;
    const requestEpoch = accountEpoch, requestScope = accountScope;
    const renameToken = action === "rename" ? host.getAttribute("data-lff-rename-token") : null;
    const entry = profiles.get(record.id);
    const method = nativeOptions(record.owner, "UserMenu")?.methods?.[action === "favorite" ? "addFav" : "changeName"];
    if (entry?.state !== "ready" || entry.native.relation !== 2 || typeof method !== "function") return result(host, "unavailable");
    if (busy.has(record.id)) return;
    busy.add(record.id); result(host, "loading");
    let finished = false;
    const timeout = setTimeout(() => finish(false), 12000);
    function requestStillCurrent() {
      if (action !== "rename") return true;
      observeAccount();
      return requestAccount?.known === true && accountEpoch === requestEpoch && accountScope === requestScope;
    }
    function finish(ok) {
      if (finished) return;
      finished = true; clearTimeout(timeout); busy.delete(record.id);
      if (!requestStillCurrent()) return;
      if (action === "rename" && host.getAttribute("data-lff-rename-token") !== renameToken) { publish(record, entry); return; }
      result(host, ok ? "saved" : "error");
      if (action === "rename") setAttr(host, "data-lff-rename-result", ok ? "saved" : "error");
      publish(record, entry);
    }
    const context = contextFor(record.owner, { friendData: { ...entry.native }, friendInfo: record.owner.$store?.state?.app?.friendInfo || {},
      isFav: entry.native.stick ? 1 : 0, isOlineRm: entry.native.remindSwitch, editName: false,
      $emit(name, data) {
        if (finished) return;
        if (action === "favorite" && name === "changeStick" && [0, 1, false, true].includes(data)) {
          updateEntries(record.id, "stick", Number(Boolean(data))); finish(true);
        } else if (action === "rename" && name === "changeUserName" && typeof data === "string") {
          if (!requestStillCurrent()) { finish(false); return; }
          updateEntries(record.id, "userName", data); finish(true);
        }
      } });
    try {
      const answer = action === "favorite" ? method.call(context) : method.call(context, value);
      if (answer?.catch) answer.catch(() => finish(false));
    } catch { finish(false); }
  }
  function action(event) {
    if (!event.isTrusted || (event.type === "click" && (event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey))) return;
    const path = event.composedPath();
    const host = path.find(el => el instanceof Element && el.matches("livu-row-actions, livu-profile-preview"));
    const button = path[0]?.closest?.("[data-action]");
    if (!host || !visible(host) || !button || button.getRootNode() !== host.shadowRoot) return;
    let name = button.getAttribute("data-action");
    if (["add-contact", "delete-contact"].includes(name) && hovering?.matches(".im-bar .cur-msg-list > li")) {
      const record = recordFor(hovering);
      if (!record || String(record.id) !== host.getAttribute("data-lff-target")) {
        event.preventDefault(); event.stopImmediatePropagation(); syncCompactRows();
      }
      return;
    }
    if (event.type === "keydown") {
      if (event.isComposing || event.keyCode === 229) return;
      if (event.key !== "Enter" || event.repeat || button.id !== "rename-input") return;
      name = "rename-save";
    }
    if (!new Set(["copy", "call", "favorite", "rename-save", "profile", "message"]).has(name) || button.disabled) return;
    const editRecord = name === "rename-save" ? renameRecordFor(host) : null;
    if (name === "rename-save" && !editRecord) { result(host, "unavailable"); return; }
    const row = editRecord?.row || hovering;
    const record = editRecord || recordFor(row);
    if (!record || record.id !== Number(host.getAttribute("data-lff-target")) || (!editRecord && !visible(row))) return;
    event.preventDefault(); event.stopImmediatePropagation();
    try {
      if (name === "profile") { result(host, openProfile(record) ? "opened" : "unavailable"); }
      else if (name === "message") {
        const store = record.owner.$store;
        if (!store?.commit) return result(host, "unavailable");
        store.commit("setImChatConfig", { show: true, friendId: record.id, headImg: record.item.headImg, userName: record.item.userName });
        result(host, "opened");
      } else if (name === "copy") {
        const link = profileRoute(record);
        if (!link) return result(host, "unavailable");
        navigator.clipboard.writeText(link).then(() => result(host, "copied"), () => result(host, "copy", link));
      } else if (name === "favorite") changeFriend(record, name, null, host);
      else if (name === "rename-save") {
        const value = host.shadowRoot.querySelector("#rename-input")?.value;
        if (typeof value === "string" && value.length <= 30) changeFriend(record, "rename", value, host);
      } else if (name === "call") {
        const entry = profiles.get(record.id);
        const method = nativeOptions(record.owner, "DialogBox")?.methods?.sendCall;
        if (entry?.state !== "ready" || typeof method !== "function" || !record.owner.$callMgr) return result(host, "unavailable");
        if (Date.now() - lastCall < 2000) return;
        lastCall = Date.now();
        const context = contextFor(record.owner, { friendId: record.id, friendDetail: entry.native,
          payStatus: record.owner.$store?.state?.app?.userInfo?.payStatus });
        // This is Livu's original call flow, including its balance/VIP and media checks.
        method.call(context);
      }
    } catch { result(host, "error"); }
  }

  function findStore() {
    for (const element of document.querySelectorAll(".mb-nav-panel, .friend-list, .im-list, .im-chat, .im-bar, .base-video-chat.video-chat, #chat1v1-mainVideo")) {
      const store = element.__vue__?.$store;
      if (store?.state?.app?.imPanelConfig && typeof store.commit === "function") return store;
    }
    return null;
  }
  function canPin(store) {
    return document.documentElement.getAttribute("data-lff-sidebar-pinned") === "true" &&
      store.state.app.isMobile !== true && store.state.app.isLogin !== false;
  }
  function keepSidebar() {
    const store = findStore();
    if (!store) return null;
    let record = stores.get(store);
    if (!record) {
      record = { original: store.commit, tab: primaryVM()?.curTabId ?? store.state.app.imPanelConfig.tabId };
      stores.set(store, record);
      store.commit = function (type, payload, options) {
        const name = typeof type === "object" ? type?.type : type;
        const data = typeof type === "object" ? type : payload;
        if (name === "setImPanelConfig" && canPin(store)) {
          const tab = primaryVM()?.curTabId ?? record.tab;
          if (data?.show === false) {
            const replacement = { ...data, show: true, tabId: tab };
            return typeof type === "object" ? record.original.call(store, replacement, payload, options)
              : record.original.call(store, type, replacement, options);
          }
          if (data?.show === true && [0, 1].includes(data.tabId)) record.tab = data.tabId;
        }
        const result = record.original.call(store, type, payload, options);
        if (["setVideoPopState", "setShow1v1Pop", "setMatchCallData", "setBizData", "setCurRoomNum", "setCurCallRole", "resetVideoChat"].includes(name)) {
          syncVideoCallSignal(store);
        }
        return result;
      };
    }
    const pinned = canPin(store);
    const panel = document.querySelector(".mb-nav-panel");
    setAttr(document.documentElement, "data-lff-docked", pinned ? "true" : null);
    const call = store.state.app.showVideoPop || store.state.app.show1v1Pop;
    setAttr(document.documentElement, "data-lff-call-active", call ? "true" : null);
    if (pinned && !store.state.app.imPanelConfig.show) store.commit("setImPanelConfig", { show: true, tabId: record.tab });
    if (pinned && panel && visible(panel)) {
      const rect = panel.getBoundingClientRect();
      const side = rect.left < innerWidth - rect.right ? "left" : "right";
      setAttr(document.documentElement, "data-lff-dock-side", side);
      const space = side === "left" ? rect.right : innerWidth - rect.left;
      document.documentElement.style.setProperty("--lff-sidebar-space", `${Math.ceil(space)}px`);
    }
    return store;
  }
  function sync() {
    timer = null;
    const store = keepSidebar();
    syncVideoCallSignal(store || findStore());
    const account = observeAccount();
    setAttr(document.documentElement, "data-lff-account-id", account.id);
    syncCompactRows();
    if (hovering) {
      const record = recordFor(hovering), entry = record && profiles.get(record.id);
      if (record && entry) publish(record, entry);
    }
  }
  function schedule() { if (timer == null) timer = setTimeout(sync, 80); }
  document.addEventListener("pointerover", hover, true);
  document.addEventListener("focusin", hover, true);
  document.addEventListener("click", action, true);
  document.addEventListener("keydown", action, true);
  const observer = new MutationObserver(mutations => {
    if (mutations.some(m => m.attributeName === "data-lff-sidebar-pinned" || m.type === "childList" &&
      [...m.addedNodes, ...m.removedNodes].some(node => node.nodeType === 1 &&
        (node.matches(".mb-nav-panel, .im-list, .friend-list") || node.querySelector(".mb-nav-panel, .im-list, .friend-list"))))) schedule();
    if (mutations.some(m => m.type === "childList" && (m.target.nodeType === 1 && m.target.closest(".base-video-chat.video-chat") ||
      [...m.addedNodes, ...m.removedNodes].some(node => node.nodeType === 1 &&
        (node.matches(".base-video-chat.video-chat, #chat1v1-mainVideo, #chat1v1-miniVideo, video") ||
          node.querySelector(".base-video-chat.video-chat, #chat1v1-mainVideo, #chat1v1-miniVideo, video")))))) schedule();
    if (mutations.some(m => m.type === "childList" && m.target.nodeType === 1 &&
      m.target.closest(".friend-list .flist-box, .im-list") &&
      [...m.addedNodes, ...m.removedNodes].some(node => node.nodeType === 1 &&
        (node.matches(".ocell") || node.querySelector(".ocell"))))) scheduleAges();
  });
  observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["data-lff-sidebar-pinned"] });
  syncAges();
  window.addEventListener("resize", schedule);
  document.addEventListener("visibilitychange", schedule);
  setInterval(sync, 1000); sync();
})();
