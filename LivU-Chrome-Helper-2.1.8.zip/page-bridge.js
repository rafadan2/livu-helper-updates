(() => {
  "use strict";
  if (window.__livuFriendsPageBridge) return;
  window.__livuFriendsPageBridge = true;

  // These are existing Livu Vue methods, verified in the current public app bundle.
  // No credentials, private endpoints, or extension APIs are read in this world.
  const POLL_MS = 10000;
  const FRESH_MS = 30000;
  const BATCH_SIZE = 100;
  const PAGE_GAP_MS = 1000;
  const LOAD_TIMEOUT_MS = 20000;
  const panels = new WeakMap();
  const normalLists = new WeakMap();
  const pageLoads = new WeakMap();
  const favoriteLists = new WeakMap();
  const rowRecords = new WeakMap();
  const statuses = new WeakMap();
  let scheduled = false;

  function visible(element) {
    if (!element?.isConnected || document.hidden) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== "hidden";
  }

  function idFor(item) {
    const text = String(item?.id ?? "");
    const id = Number(text);
    return /^\d{1,16}$/.test(text) && Number.isSafeInteger(id) && id > 0 ? id : null;
  }

  function setAttribute(element, name, value) {
    if (value == null) {
      if (element.hasAttribute(name)) element.removeAttribute(name);
    } else if (element.getAttribute(name) !== String(value)) {
      element.setAttribute(name, String(value));
    }
  }

  function findBellVM(panel) {
    const vm = panel.__vue__;
    return vm && Array.isArray(vm.onlineList) && typeof vm.cancelPanel === "function" ? vm : null;
  }

  function findFriendVM() {
    for (const list of document.querySelectorAll(".friend-list")) {
      if (list.closest(".im-online")) continue;
      const vm = list.__vue__;
      if (vm && typeof vm.jumpToProfile === "function") return vm;
    }
    return null;
  }

  function favoritesOnly(list) {
    // Safe before the isolated-world preferences have finished loading.
    return list.getAttribute("data-lff-favorites-only") !== "false";
  }

  function rememberStatus(vm, item, property, value) {
    const result = vm.$set(item, property, value);
    if (property === "status" && idFor(item) != null) {
      statuses.set(item, { value: typeof value === "number" ? value : NaN, time: Date.now() });
      schedule();
    }
    return result;
  }

  function statusContext(vm, fields = {}) {
    // Call the original unbound method with a small proxy. Its $set still updates
    // the real row objects; the callback records when the server actually replies.
    const context = Object.create(vm);
    Object.defineProperty(context, "$set", {
      value: (item, property, value) => rememberStatus(vm, item, property, value)
    });
    for (const [key, value] of Object.entries(fields)) {
      Object.defineProperty(context, key, { value });
    }
    return context;
  }

  function callStatusMethod(method, context, args) {
    try {
      const result = method.apply(context, args);
      if (result && typeof result.catch === "function") result.catch(() => {});
    } catch {
      // Existing status expires naturally. A failed request is never "offline".
    }
  }

  function syncBell(panel, friendVM, now) {
    const vm = findBellVM(panel);
    const list = panel.querySelector(".friend-list");
    if (!vm || !list) return;
    let record = panels.get(panel);
    if (!record || record.vm !== vm) {
      record = { vm, lastRequest: -Infinity, ids: "" };
      panels.set(panel, record);
    }
    const items = vm.onlineList;
    const rows = Array.from(list.children).filter(element => element.matches(".ocell"));
    // Livu renders this list in array order with index keys. Guard against an
    // incomplete Vue render so a row cannot open the wrong person's profile.
    if (rows.length !== items.length) {
      for (const row of rows) {
        rowRecords.delete(row);
        setAttribute(row, "data-lff-user-id", null);
        setAttribute(row, "data-lff-profile-ready", null);
        setAttribute(row, "data-lff-status", null);
      }
      return;
    }
    for (let index = 0; index < rows.length; index++) {
      const row = rows[index];
      const item = items[index];
      const id = idFor(item);
      const name = row.querySelector(".name")?.textContent.trim();
      if (id == null || name !== String(item.userName ?? "").trim()) {
        rowRecords.delete(row);
        setAttribute(row, "data-lff-user-id", null);
        setAttribute(row, "data-lff-profile-ready", null);
        setAttribute(row, "data-lff-status", null);
        continue;
      }
      rowRecords.set(row, { panel, vm, item, id });
      setAttribute(row, "data-lff-user-id", id);
      const favorite = item.stick == null
        ? Boolean(friendVM?.remindFriend?.some(friend => idFor(friend) === id)) : Boolean(item.stick);
      setAttribute(row, "data-lff-favorite", favorite ? "true" : "false");
      setAttribute(row, "data-lff-profile-ready", friendVM ? "true" : null);
      let state = statuses.get(item);
      if (!state && Number.isInteger(item.status)) {
        state = { value: item.status, time: now };
        statuses.set(item, state);
      }
      const fresh = state && now - state.time <= FRESH_MS && [0, 1, 2].includes(state.value);
      setAttribute(row, "data-lff-status", fresh ? state.value : null);
    }
    const eligible = favoritesOnly(list) ? items.filter((item, index) =>
      rows[index].getAttribute("data-lff-favorite") === "true") : items;
    const ids = eligible.map(idFor).filter(Boolean).join(",");
    if (!ids || !visible(panel)) return;
    const method = vm.$options?.methods?.apiGetGoddessStatus;
    if (typeof method !== "function" || typeof vm.$set !== "function") return;
    if (record.ids !== ids || now - record.lastRequest >= POLL_MS) {
      record.ids = ids;
      record.lastRequest = now;
      // Reuse Livu's status lookup with its existing authenticated app context.
      callStatusMethod(method, statusContext(vm), [eligible]);
    }
  }

  function refreshFilteredFriends(list, now, bellVisible) {
    if (bellVisible || !visible(list) || list.getAttribute("data-lff-online-only") !== "true") return;
    const vm = list.__vue__;
    const method = vm?.$options?.methods?.getFriendsStatus;
    if (!vm || typeof method !== "function" || typeof vm.$set !== "function") return;
    const groups = (favoritesOnly(list) ? ["remindFriend"] : ["remindFriend", "friendList"])
      .filter(key => Array.isArray(vm[key]) && vm[key].length);
    let record = normalLists.get(list);
    if (!record || record.vm !== vm) {
      record = { vm, requested: new WeakMap() };
      normalLists.set(list, record);
    }
    for (const key of groups) {
      // Check new pages immediately without repeatedly checking earlier pages.
      const items = vm[key].filter(item => idFor(item) != null &&
        now - (record.requested.get(item) ?? -Infinity) >= POLL_MS);
      for (let start = 0; start < items.length; start += BATCH_SIZE) {
        const batch = items.slice(start, start + BATCH_SIZE);
        for (const item of batch) record.requested.set(item, now);
        callStatusMethod(method, statusContext(vm, { [key]: batch }), [batch, key]);
      }
    }
  }

  function markFavorites(list, vm) {
    if (!Array.isArray(vm?.remindFriend)) return;
    let record = favoriteLists.get(list);
    if (!record || record.vm !== vm) {
      record = { vm, rows: new Map() }; favoriteLists.set(list, record);
    }
    const ids = new Set(vm.remindFriend.map(idFor).filter(Boolean));
    for (const [id, row] of record.rows) {
      if (!ids.has(id) || !row.isConnected || !list.contains(row)) {
        setAttribute(row, "data-lff-favorite", null); record.rows.delete(id);
      }
    }
    for (const id of ids) {
      let row = record.rows.get(id);
      if (!row) row = list.querySelector(`.ocell[data-id="${id}"]`);
      if (row) { record.rows.set(id, row); setAttribute(row, "data-lff-favorite", "true"); }
    }
  }

  function loaderFor(list) {
    const vm = list.__vue__;
    markFavorites(list, vm);
    if (!vm || typeof vm.getFriendsData !== "function" ||
        !Array.isArray(vm.friendList) || !Array.isArray(vm.remindFriend) ||
        !Number.isSafeInteger(vm.pageNum) || vm.pageNum < 1 ||
        typeof vm.loadLock !== "boolean" || typeof vm.noMorePage !== "boolean") return null;
    let record = pageLoads.get(list);
    if (!record || record.vm !== vm) {
      record = { vm, original: vm.getFriendsData, method: vm.$options?.methods?.getFriendsData,
        pending: null, nextAt: 0, error: false, emptyPages: 0, busySince: null,
        boundary: false, deferred: [], favoriteItems: new WeakSet() };
      pageLoads.set(list, record);
      // Disable Livu's scroll-triggered pagination. Only the explicit + action
      // below may append regular friends. Allow its native initial page once.
      let initialAllowed = vm.loadLock || vm.pageNum > 1 || vm.friendList.length + vm.remindFriend.length > 0;
      vm.getFriendsData = function () {
        if (initialAllowed || vm.loadLock || record.pending || record.error ||
            vm.pageNum > 1 || vm.friendList.length + vm.remindFriend.length > 0) return;
        initialAllowed = true;
        return record.original.call(vm);
      };
    }
    for (const item of vm.remindFriend) if (item && typeof item === "object") record.favoriteItems.add(item);
    setAttribute(list, "data-lff-paging-controlled", "true");
    return record;
  }

  function requestPage(list, record, now, favoritePage) {
    const vm = record.vm;
    record.pending = { page: vm.pageNum, count: vm.friendList.length + vm.remindFriend.length };
    record.busySince = now;
    setAttribute(list, "data-lff-loading", "loading");
    try {
      let result;
      if (favoritePage) {
        // Call the original unbound routine with forwarded pagination fields.
        // A mixed boundary page never appends its regular friends to the UI.
        const context = Object.create(vm);
        for (const key of ["pageNum", "loadLock", "noMorePage"]) {
          Object.defineProperty(context, key, { get: () => vm[key], set: value => { vm[key] = value; } });
        }
        Object.defineProperty(context, "sortFriends", { value: items => {
          const favorites = items.filter(item => Boolean(item.stick));
          const regular = items.filter(item => !item.stick);
          if (regular.length) { record.boundary = true; record.deferred.push(...regular); }
          if (favorites.length) vm.sortFriends(favorites);
        }});
        result = record.method.call(context);
      } else {
        result = record.original.call(vm);
      }
      if (result && typeof result.catch === "function") result.catch(() => {
        record.error = true;
        setAttribute(list, "data-lff-loading", "error");
      });
    } catch {
      record.error = true;
      setAttribute(list, "data-lff-loading", "error");
    }
  }

  function loadFavorites(list, now, bellVisible) {
    const record = loaderFor(list);
    if (!record) return;
    const vm = record.vm;
    if (record.pending && !vm.loadLock && vm.pageNum > record.pending.page) {
      const count = vm.friendList.length + vm.remindFriend.length;
      record.emptyPages = count > record.pending.count ? 0 : record.emptyPages + 1;
      record.pending = null;
      record.error = record.emptyPages >= 2;
      record.nextAt = now + PAGE_GAP_MS;
    }
    if (vm.loadLock || record.pending) {
      if (record.busySince == null) record.busySince = now;
      if (now - record.busySince >= LOAD_TIMEOUT_MS) record.error = true;
      setAttribute(list, "data-lff-loading", record.error ? "error" : "loading");
      return;
    }
    record.busySince = null;
    if (record.error) {
      setAttribute(list, "data-lff-loading", "error");
      return;
    }
    if (!favoritesOnly(list)) {
      setAttribute(list, "data-lff-loading", vm.noMorePage && !record.deferred.length ? "complete" : "manual");
      return;
    }
    // Removing a favorite locally must not stop the remaining favorite pages.
    if (record.boundary || vm.friendList.some(item => !record.favoriteItems.has(item))) {
      setAttribute(list, "data-lff-loading", "favorites");
      return;
    }
    if (vm.noMorePage) {
      setAttribute(list, "data-lff-loading", "complete");
      return;
    }
    // Fail closed if a changed site no longer exposes a safe unbound loader.
    if (typeof record.method !== "function" || typeof vm.sortFriends !== "function") {
      setAttribute(list, "data-lff-loading", "favorites");
      return;
    }
    setAttribute(list, "data-lff-loading", "loading");
    if (bellVisible || !visible(list) || now < record.nextAt) return;
    requestPage(list, record, now, true);
  }

  function sync() {
    scheduled = false;
    const now = Date.now();
    const friendVM = findFriendVM();
    const bells = Array.from(document.querySelectorAll(".im-online"));
    for (const panel of bells) syncBell(panel, friendVM, now);
    const bellVisible = bells.some(visible);
    for (const list of document.querySelectorAll(".friend-list")) {
      if (!list.closest(".im-online")) {
        loadFavorites(list, now, bellVisible);
        refreshFilteredFriends(list, now, bellVisible);
      }
    }
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(sync, 60);
  }

  function profileAction(event) {
    if (!event.isTrusted || !(event.target instanceof Element)) return;
    if (event.type === "click" && (event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey)) return;
    if (event.type === "keydown" && (event.repeat || !["Enter", " "].includes(event.key))) return;
    const row = event.target.closest(".im-online .friend-list > .ocell");
    if (!row || event.target.closest(".cell-right, .f-switch, button, input, select, textarea, a, label")) return;
    if (event.type === "keydown" && event.target !== row) return;
    const record = rowRecords.get(row);
    const friendVM = findFriendVM();
    if (!record || !friendVM || !record.panel.isConnected) return;
    const rows = Array.from(record.vm.onlineList || []);
    const index = Array.from(row.parentElement.children).filter(el => el.matches(".ocell")).indexOf(row);
    if (rows[index] !== record.item || idFor(rows[index]) !== record.id ||
        row.querySelector(".name")?.textContent.trim() !== String(record.item.userName).trim()) return;
    event.preventDefault();
    event.stopPropagation();
    // Only the user's profile click reaches these native navigation functions.
    const openProfile = friendVM.jumpToProfile.bind(friendVM);
    record.vm.cancelPanel();
    openProfile(record.id);
  }

  function manualPageAction(event) {
    if (!event.isTrusted || event.button !== 0) return;
    const path = event.composedPath();
    const button = path[0];
    const host = path.find(node => node instanceof Element && node.tagName === "LIVU-FRIEND-FILTERS");
    if (!(button instanceof Element) || button.id !== "load-more" || !host ||
        button.getRootNode() !== host.shadowRoot) return;
    const list = host.closest(".friend-list");
    if (!list || list.closest(".im-online") || favoritesOnly(list) || !visible(list)) return;
    const record = loaderFor(list);
    if (!record || record.vm.loadLock || record.pending || record.error) return;
    if (record.deferred.length) {
      record.vm.sortFriends(record.deferred.splice(0));
      schedule();
    } else if (!record.vm.noMorePage) {
      requestPage(list, record, Date.now(), false);
    }
  }

  document.addEventListener("click", manualPageAction, true);
  document.addEventListener("click", profileAction, true);
  document.addEventListener("keydown", profileAction, true);
  document.addEventListener("visibilitychange", schedule);
  const observer = new MutationObserver(mutations => {
    if (mutations.some(mutation => mutation.target.nodeType === Node.ELEMENT_NODE &&
        (mutation.target.closest(".friend-list, .im-online") ||
        [...mutation.addedNodes, ...mutation.removedNodes].some(node => node.nodeType === Node.ELEMENT_NODE &&
          (node.matches(".friend-list, .im-online") || node.querySelector(".friend-list, .im-online")))))) schedule();
  });
  observer.observe(document.documentElement, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ["class", "src", "data-lff-online-only", "data-lff-favorites-only"]
  });
  setInterval(sync, 1000);
  sync();
})();
