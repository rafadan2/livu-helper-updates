# LivU Helper for Chrome · 2.1.3

This combines Friends Filters with the contacts, account picker, Notion sync and greetings used by Safari. Both browsers are generated from `helper-shared/`. Android uses the same private account and contact lists.

Version 2.1.3 automatically fills the password after you select an email and press Next. Enter the shared LivU password once per tab, or cancel to fill email only. Editing the email cancels automatic password filling; existing passwords, signup and verification screens stay untouched. The helper never presses Sign in. Synthetic Chrome tests cover the sequence in an isolated content world.

## Install or update

This version includes **Helper updates** in the extension popup and the webpage Contacts/Autofill settings. Press **Check for updates**; a newer version offers its Chrome ZIP. Replace the files in the original extension folder, Reload it at `chrome://extensions`, then reload LivU. Keep the same folder and extension entry to preserve saved data. Unpacked extensions cannot silently replace their own files. The code-only update channel is prepared but not published yet, so checks currently show unavailable. This check sends no Notion token or saved records.

Extract `LivU-Chrome-Helper-2.1.3.zip`. Replace files in the **original installed extension folder**, open `chrome://extensions`, click **Reload**, then reload LivU. Its new name is **LivU Helper**. Keep the original folder and extension entry to preserve settings; avoid a second copy.

For first installation, enable **Developer mode**, choose **Load unpacked** and select the extracted folder containing `manifest.json`. Keep that folder permanently.

## Contacts, accounts and greetings

- Press the floating **+** on a person's profile to save its visible name/link quietly, keeping your current messages/contacts view. **Contacts** opens the shared list. Add/edit by link and notes are also available.
- Connect the existing private Notion Contacts list through **Contacts** and Accounts through **Autofill → Account setup & sync**. Each panel shows connection health and refresh times. Enter tokens directly on the device.
- **Autofill** and the dropdown arrow inside the email field show account numbers, email addresses and recorded coins. Type in the email field to filter the dropdown. Connect Notion or import your own private `accounts.json`. GitHub downloads contain no account snapshot. Enter the shared LivU password when you first select an account; it stays in tab memory until reload or close. Press Next and the password fills automatically, without another account selection. Press LivU's sign-in button yourself. **Autofill → Account setup & sync → Forget password** clears the helper's password and pending fill. The pending step expires after two minutes; you can still choose **Fill #N** on the password screen.
- Search/sort Contacts, use **Online only**, then **Select all** or **Select top 20**. Status is a snapshot expiring after two minutes. Selection does not send messages.
- **Send selam** processes selected contacts with the signed-in account. It checks the selected chats first, then shows one approval with the contact count and total cost: free chats add 0 coins and paid chats add 9 each. Cancel sends nothing. Chats that become paid after approval are skipped. Uncertain results are held for checking. Drafts, active calls and sender changes stop unsafe actions.

Contacts refresh when opened, manually synced or edited. Accounts refresh when Autofill opens or **Refresh coins** is tapped. Failures keep cached rows. Balances are metadata/Notion snapshots. Passwords, pins, filters and greeting history do not sync across devices.

## Friend tools

Open LivU's Friends or bell list. **Favorites**, **Online**, multi-country, age and name filters work together. Unknown ages are included by default. More regular friends load only through the list's **+**, separate from the floating save-contact **+**.

Hover a loaded person/conversation for available profile/photo previews, copy, message, native favorite/rename, pin and video actions. These use LivU's own controls and keep their usual behavior and costs. Pins stay local and are scoped to the signed-in account where LivU supplies its ID. The pinned sidebar preserves the loaded list and scroll for the page session, stepping aside during calls.

During an active video call, the phrase panel **copies** phrases without typing or sending them. The extension popup holds friend filter settings; Contacts and Autofill appear on the LivU page.

## Privacy and updates

Runs on HTTPS LivU pages. Chrome storage holds contact/account caches, Notion connections, settings, pins and action history. Login passwords stay in tab memory. The worker accepts only this extension's top-level LivU pages, sends Notion requests only to its fixed HTTPS API and executes packaged page code. No analytics, payment details or passwords are bundled.

Copy a contacts backup before clearing storage. Notion deletions do not remove browser cached contacts; pending local edits take priority. Opening the list on another device refreshes its data. Updating code requires replacing/reloading each installed package.

See included **SYNC.md** for refresh timing and the shared release process. Automated checks and local dummy previews pass; live behavior still needs checking in your installation.
