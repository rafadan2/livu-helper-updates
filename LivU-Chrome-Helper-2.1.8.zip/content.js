(() => {
  "use strict";
  if (globalThis.__livuFriendFiltersStarted) return;
  globalThis.__livuFriendFiltersStarted = true;

  const Core = globalThis.LivuFriendFiltersCore;
  const LIST_SELECTOR = ".friend-list";
  const ROW_SELECTOR = ".flist-box .ocell";
  const controllers = new Map();
  let settings = { ...Core.DEFAULTS };
  let initialized = false;
  let saveFailed = false;
  let reconcileTimer;

  const PANEL_CSS = `
    :host { color-scheme:light; font:inherit; font-size:12px; color:#010102;
      line-height:1.4; text-align:start; }
    * { box-sizing:border-box; }
    .panel { width:100%; }
    .search { display:flex; align-items:center; gap:9px; height:40px; padding:0 12px;
      background:#f2f2f4; border-radius:10px; }
    :host([data-bell-space]) .search { margin-inline-end:40px; }
    .search svg { width:17px; height:17px; flex:none; color:#777; }
    .search:focus-within { box-shadow:0 0 0 1.5px #9254ff; }
    input { font:inherit; font-size:14px; border:0; outline:0; background:transparent;
      width:100%; min-width:0; padding:0; color:inherit; }
    input::placeholder { color:#999; }
    button { font:inherit; color:inherit; border:0; background:transparent; cursor:pointer; }
    .clear { display:grid; place-items:center; flex:none; width:22px; height:24px; padding:0;
      color:#888; font-size:20px; border-radius:5px; }
    .clear:hover { color:#7b2cff; background:#e9e3f4; }
    .controls { display:grid; grid-template-columns:minmax(0,1fr) auto auto auto auto; gap:6px;
      align-items:center; margin-top:8px; }
    .country-filter,.age-filter { position:relative; min-width:0; }
    .filter-trigger { display:flex; align-items:center; justify-content:center; gap:5px; height:32px;
      max-width:100%; padding:0 8px; border:0; border-radius:8px; background:#f2f2f4;
      color:#49474e; font:inherit; white-space:nowrap; cursor:pointer; }
    .filter-trigger:hover,.filter-trigger[aria-expanded=true] { background:#f1eaff; color:#7130c3; }
    .filter-trigger span { overflow:hidden; text-overflow:ellipsis; }
    .filter-menu { position:fixed; top:8px; left:8px; z-index:120; width:max-content; min-width:min(210px,calc(100vw - 16px));
      max-width:min(280px,calc(100vw - 16px)); padding:8px; border:1px solid #eee6f5; border-radius:10px;
      background:white; box-shadow:0 8px 28px #35204722; overflow-y:auto; overscroll-behavior:contain; pointer-events:auto; }
    .age-menu { width:min(225px,calc(100vw - 16px)); }
    .filter-menu[hidden] { display:none!important; }
    .country-options { display:grid; gap:2px; max-height:190px; overflow:auto; overscroll-behavior:contain; }
    .country-options button { display:flex; align-items:center; justify-content:space-between; gap:8px; width:100%;
      min-height:27px; padding:3px 6px; border-radius:6px; color:#5d5565; text-align:left; cursor:pointer; }
    .country-options button:hover { background:#f8f5fb; }
    .country-options button[aria-pressed=true] { color:#7130c3; }
    .country-options .check { color:#8134d5; font-weight:700; }
    .all-countries { width:100%; padding:4px 5px 7px; text-align:left; color:#8134d5; font-size:11px; }
    .all-countries:disabled { color:#a99fad; cursor:default; }
    .age-fields { display:grid; grid-template-columns:1fr 1fr; gap:7px; }
    .age-fields label { display:grid; gap:4px; color:#82788c; font-size:10px; }
    .age-fields input { width:100%; height:30px; padding:0 7px; border:1px solid #ece6f1;
      border-radius:7px; background:#faf9fc; font:inherit; font-size:12px; }
    .include-unknown { display:flex; align-items:center; justify-content:space-between; gap:8px; width:100%;
      margin-top:5px; padding:4px 5px; color:#5d5565; font-size:11px; text-align:left; }
    .include-unknown[aria-checked=true] { color:#7130c3; }
    .age-hint { margin:4px 5px 2px; color:#a197aa; font-size:10px; }
    .online,.favorites { display:flex; align-items:center; gap:6px; padding:0; height:32px; white-space:nowrap; }
    .favorites { color:#999; }
    .favorites svg { width:17px; height:17px; fill:none; }
    .favorites[aria-checked=true] { color:#7b2cff; }
    .favorites[aria-checked=true] svg { fill:currentColor; }
    .online-text { color:#67646d; }
    .track { width:28px; height:16px; flex:none; padding:2px; background:#d3d1d8;
      border-radius:20px; transition:background .15s; }
    .track i { display:block; width:12px; height:12px; border-radius:50%; background:white;
      box-shadow:0 1px 2px #0002; transition:transform .15s; }
    [role=switch][aria-checked=true] .track { background:linear-gradient(110deg,#ad3fff,#7020ff); }
    [role=switch][aria-checked=true] .track i { transform:translateX(12px); }
    .online[aria-checked=true] .online-text { color:#7b2cff; }
    .summary { display:flex; align-items:center; gap:5px; color:#9b96a2; }
    .count { font-size:10px; font-variant-numeric:tabular-nums; white-space:nowrap; }
    .more { width:19px; height:22px; border-radius:5px; padding:0; color:#8033ff; font-size:18px; }
    .more:hover { background:#f1eaff; }
    .progress { width:10px; height:10px; border:1.5px solid #e1d7ef; border-top-color:#8033ff;
      border-radius:50%; animation:spin .85s linear infinite; }
    .progress.error { border:0; width:auto; height:auto; animation:none; color:#ad7418; font-weight:700; }
    input:focus-visible, button:focus-visible { outline:2px solid #8940e8; outline-offset:3px; }
    .empty { margin:10px 0 3px; color:#9b96a2; text-align:center; }
    .notice { margin:7px 0 0; color:#8b5a13; font-size:11px; }
    [hidden] { display:none!important; }
    @keyframes spin { to { transform:rotate(360deg); } }
    @media (prefers-reduced-motion:reduce) { .track,.track i { transition:none; } .progress { animation:none; } }
  `;

  function languageFor(list) {
    return document.documentElement.lang ||
      (list.closest(".im-panel")?.querySelector(".p-title")?.textContent.includes("Arkadaş") ? "tr" : "en");
  }

  function setHidden(element, hidden) {
    if (hidden) {
      if (element.getAttribute("data-lff-hidden") !== "true") element.setAttribute("data-lff-hidden", "true");
    } else if (element.hasAttribute("data-lff-hidden")) {
      element.removeAttribute("data-lff-hidden");
    }
  }

  function saveSettings(patch) {
    settings = Core.normalizeSettings({ ...settings, ...patch });
    for (const controller of controllers.values()) controller.update();
    try {
      chrome.storage.local.set({ [Core.STORAGE_KEY]: settings }).then(() => {
        if (saveFailed) {
          saveFailed = false;
          for (const controller of controllers.values()) controller.update();
        }
      }).catch(onSaveError);
    } catch { onSaveError(); }
  }

  function onSaveError() {
    saveFailed = true;
    for (const controller of controllers.values()) controller.update();
  }

  class FilterPanel {
    constructor(list) {
      this.list = list;
      this.isBell = Boolean(list.closest(".im-online"));
      this.originalRowAttributes = new WeakMap();
      this.decorations = new WeakMap();
      this.rowData = new WeakMap();
      this.onlineDirty = new Set();
      this.favoriteDirty = new Set();
      this.ageDirty = new Set();
      this.matches = new WeakMap();
      this.rows = null;
      this.sections = [];
      this.countriesDirty = true;
      this.lastFavorites = null;
      this.lastCountries = "";
      this.choices = [];
      this.language = languageFor(list);
      this.t = Core.translations(this.language);
      this.countries = new Map();
      this.optionSignature = "";
      this.query = "";
      this.header = null;
      this.timer = null;
      this.host = document.createElement("livu-friend-filters");
      this.host.setAttribute("aria-label", this.t.title);
      const shadow = this.host.attachShadow({ mode: "open" });
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(PANEL_CSS);
      this.sheet = sheet;
      shadow.adoptedStyleSheets = [sheet];
      // Static markup only; site text is assigned using textContent and Option.
      shadow.innerHTML = `<section class="panel">
        <div class="search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
          stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg>
          <input id="search" type="text" spellcheck="false" autocomplete="off">
          <button class="clear" type="button" hidden aria-label=""></button></div>
        <div class="controls">
          <div class="country-filter"><button id="country-toggle" class="filter-trigger" type="button" aria-expanded="false"><span></span>⌄</button>
            <div id="country-menu" class="filter-menu" role="group" hidden><button id="all-countries" class="all-countries" type="button"></button>
              <div class="country-options"></div></div></div>
          <div class="age-filter"><button id="age-toggle" class="filter-trigger" type="button" aria-expanded="false"><span></span>⌄</button>
            <div id="age-menu" class="filter-menu age-menu" role="group" hidden><div class="age-fields">
              <label><span id="min-age-label"></span><input id="min-age" type="number" min="18" max="120" step="1"></label>
              <label><span id="max-age-label"></span><input id="max-age" type="number" min="18" max="120" step="1"></label></div>
              <button id="include-unknown" class="include-unknown" type="button" role="switch" aria-checked="true"><span class="include-label"></span><span class="track" aria-hidden="true"><i></i></span></button>
              <p class="age-hint"></p></div></div>
          <button id="favorites" class="favorites" type="button" role="switch" aria-checked="true">
            <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true">
              <path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.4-5.7-3-5.7 3 1.1-6.4L2.8 9.7l6.4-.9z"/></svg>
            <span class="track" aria-hidden="true"><i></i></span></button>
          <button id="online" class="online" type="button" role="switch" aria-checked="false">
            <span class="online-text"></span><span class="track" aria-hidden="true"><i></i></span></button>
          <span class="summary" role="status" aria-live="polite"><span class="progress" aria-hidden="true" hidden></span>
            <span class="count"></span><button id="load-more" class="more" type="button" hidden>+</button></span></div>
        <p class="empty" hidden></p><p class="notice" role="status" hidden></p>
      </section>`;
      this.ui = {
        search: shadow.querySelector("#search"), clear: shadow.querySelector(".clear"),
        online: shadow.querySelector("#online"), favorites: shadow.querySelector("#favorites"),
        more: shadow.querySelector("#load-more"), summary: shadow.querySelector(".summary"),
        countryToggle: shadow.querySelector("#country-toggle"), countryMenu: shadow.querySelector("#country-menu"),
        countryOptions: shadow.querySelector(".country-options"), allCountries: shadow.querySelector("#all-countries"),
        ageToggle: shadow.querySelector("#age-toggle"), ageMenu: shadow.querySelector("#age-menu"),
        minAge: shadow.querySelector("#min-age"), maxAge: shadow.querySelector("#max-age"),
        includeUnknown: shadow.querySelector("#include-unknown"), count: shadow.querySelector(".count"),
        progress: shadow.querySelector(".progress"), empty: shadow.querySelector(".empty"),
        notice: shadow.querySelector(".notice")
      };
      shadow.querySelector(".online-text").textContent = this.t.online;
      this.ui.search.placeholder = this.t.search;
      this.ui.search.setAttribute("aria-label", this.t.search);
      this.ui.clear.textContent = "×";
      this.ui.clear.title = this.t.clear;
      this.ui.clear.setAttribute("aria-label", this.t.clear);
      this.ui.empty.textContent = this.t.noMatches;
      this.ui.online.title = this.t.onlineHint;
      this.ui.online.setAttribute("aria-label", this.t.onlineHint);
      this.ui.favorites.title = this.t.favoritesHint;
      this.ui.favorites.setAttribute("aria-label", this.t.favoritesHint);
      this.ui.more.title = this.t.more;
      this.ui.more.setAttribute("aria-label", this.t.more);
      this.ui.countryToggle.setAttribute("aria-label", this.t.nationality);
      this.ui.ageToggle.setAttribute("aria-label", this.t.ageRange);
      shadow.querySelector("#min-age-label").textContent = this.t.minAge;
      shadow.querySelector("#max-age-label").textContent = this.t.maxAge;
      shadow.querySelector(".include-label").textContent = this.t.includeUnknownAge;
      shadow.querySelector(".age-hint").textContent = this.t.ageHint;
      this.ui.allCountries.textContent = this.t.all;
      // Put fixed popovers in a top-level shadow root. Livu transforms and clips
      // its panels, which otherwise become the containing block for fixed items.
      this.menuPortal = document.createElement("lff-filter-popovers");
      this.menuPortal.dataset.lffList = this.isBell ? "bell" : "friends";
      Object.assign(this.menuPortal.style, {
        position: "fixed", inset: "0", zIndex: "2147483000", pointerEvents: "none"
      });
      const menuShadow = this.menuPortal.attachShadow({ mode: "open" });
      this.menuShadow = menuShadow;
      menuShadow.adoptedStyleSheets = [sheet];
      // The native sidebar uses a document-bubble clickoutside listener. Let
      // menu controls handle their click, then keep it from dismissing the panel.
      menuShadow.addEventListener("click", event => event.stopPropagation());
      menuShadow.append(this.ui.countryMenu, this.ui.ageMenu);
      (document.body || document.documentElement).append(this.menuPortal);
      this.syncCallState = () => {
        const active = document.documentElement.getAttribute("data-lff-call-active") === "true";
        if (active) this.closeMenu();
        this.menuPortal.style.visibility = active ? "hidden" : "";
      };
      this.callObserver = new MutationObserver(this.syncCallState);
      this.callObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-lff-call-active"] });
      this.syncCallState();
      this.ui.search.addEventListener("input", () => {
        this.query = this.ui.search.value;
        this.update();
      });
      this.ui.clear.addEventListener("click", () => {
        this.query = this.ui.search.value = "";
        this.update();
        this.ui.search.focus();
      });
      this.ui.search.addEventListener("keydown", event => {
        if (event.key === "Escape" && this.query) {
          event.preventDefault(); event.stopPropagation(); this.ui.clear.click();
        }
      });
      this.ui.online.addEventListener("click", () => saveSettings({ onlineOnly: !settings.onlineOnly }));
      this.ui.favorites.addEventListener("click", () => saveSettings({ favoritesOnly: !settings.favoritesOnly }));
      this.ui.countryToggle.addEventListener("click", () => this.toggleMenu("country"));
      this.ui.ageToggle.addEventListener("click", () => this.toggleMenu("age"));
      this.ui.allCountries.addEventListener("click", () => saveSettings({ countries: [] }));
      this.ui.countryOptions.addEventListener("click", event => {
        const button = event.target.closest("button[data-country]");
        if (!button) return;
        const selected = new Set(settings.countries);
        if (button.getAttribute("aria-pressed") !== "true") selected.add(button.dataset.country);
        else selected.delete(button.dataset.country);
        saveSettings({ countries: [...selected] });
      });
      this.ui.minAge.addEventListener("change", () => saveSettings({ ageMin: this.ui.minAge.value === "" ? null : Number(this.ui.minAge.value) }));
      this.ui.maxAge.addEventListener("change", () => saveSettings({ ageMax: this.ui.maxAge.value === "" ? null : Number(this.ui.maxAge.value) }));
      this.ui.minAge.addEventListener("blur", () => { this.ui.minAge.value = settings.ageMin ?? ""; });
      this.ui.maxAge.addEventListener("blur", () => { this.ui.maxAge.value = settings.ageMax ?? ""; });
      this.ui.includeUnknown.addEventListener("click", () => saveSettings({ includeUnknownAge: !settings.includeUnknownAge }));
      this.outsideClick = event => {
        if (!this.menuOpen) return;
        const path = event.composedPath();
        const menu = this.menuOpen === "age" ? this.ui.ageMenu : this.ui.countryMenu;
        const trigger = this.menuOpen === "age" ? this.ui.ageToggle : this.ui.countryToggle;
        if (!path.includes(menu) && !path.includes(trigger)) this.closeMenu();
      };
      document.addEventListener("pointerdown", this.outsideClick, true);
      this.escapeKey = event => {
        if (event.key !== "Escape" || !this.menuOpen) return;
        event.preventDefault(); event.stopPropagation(); this.closeMenu(true);
      };
      document.addEventListener("keydown", this.escapeKey, true);
      this.repositionMenus = () => { if (this.menuOpen) this.positionMenu(this.menuOpen); };
      document.addEventListener("scroll", this.repositionMenus, true);
      window.addEventListener("resize", this.repositionMenus);
      this.observer = new MutationObserver(mutations => {
        if (this.invalidate(mutations)) this.schedule();
      });
      this.observer.observe(list, {
        childList: true, subtree: true, characterData: true,
        attributes: true, attributeFilter: ["class", "src", "alt", "data-lff-status", "data-lff-age", "data-lff-profile-ready", "data-lff-loading", "data-lff-favorite"]
      });
      this.update();
    }

    schedule() {
      if (this.timer !== null) return;
      this.timer = setTimeout(() => { this.timer = null; this.update(); }, 90);
    }

    toggleMenu(name) {
      if (this.menuOpen === name) { this.closeMenu(); return; }
      this.menuOpen = name;
      this.renderMenus();
      this.positionMenu(name);
      requestAnimationFrame(() => (name === "country" ? this.ui.countryOptions.querySelector("button") : this.ui.minAge)?.focus());
    }

    closeMenu(returnFocus = false) {
      const name = this.menuOpen;
      this.menuOpen = ""; this.renderMenus();
      if (returnFocus) (name === "age" ? this.ui.ageToggle : this.ui.countryToggle).focus();
    }

    positionMenu(name) {
      const trigger = name === "age" ? this.ui.ageToggle : this.ui.countryToggle;
      const menu = name === "age" ? this.ui.ageMenu : this.ui.countryMenu;
      const rect = trigger.getBoundingClientRect();
      menu.style.maxHeight = `${Math.max(80, innerHeight - 16)}px`;
      const width = menu.getBoundingClientRect().width || (name === "age" ? 225 : 210);
      const height = menu.getBoundingClientRect().height;
      const left = Math.max(8, Math.min(innerWidth - width - 8, rect.left));
      const below = rect.bottom + 4;
      const desiredTop = below + height <= innerHeight - 8 ? below : rect.top - height - 4;
      const top = Math.max(8, Math.min(Math.max(8, innerHeight - height - 8), desiredTop));
      menu.style.left = `${left}px`; menu.style.top = `${top}px`;
    }

    renderMenus() {
      const countryOpen = this.menuOpen === "country", ageOpen = this.menuOpen === "age";
      this.ui.countryMenu.hidden = !countryOpen;
      this.ui.ageMenu.hidden = !ageOpen;
      this.ui.countryToggle.setAttribute("aria-expanded", String(countryOpen));
      this.ui.ageToggle.setAttribute("aria-expanded", String(ageOpen));
      if (countryOpen) this.positionMenu("country");
      if (ageOpen) this.positionMenu("age");
    }

    invalidate(mutations) {
      let changed = false;
      for (const mutation of mutations) {
        const target = mutation.target.nodeType === Node.ELEMENT_NODE ? mutation.target : mutation.target.parentElement;
        const row = target?.closest(".ocell");
        if (row && this.list.contains(row)) {
          if (mutation.attributeName === "data-lff-status" ||
              (mutation.attributeName === "class" && target.matches(".online-status"))) {
            this.onlineDirty.add(row); changed = true;
          } else if (mutation.attributeName === "data-lff-favorite") {
            this.favoriteDirty.add(row); this.countriesDirty = true; changed = true;
          } else if (mutation.attributeName === "data-lff-age") {
            this.ageDirty.add(row); changed = true;
          } else if (mutation.attributeName === "data-lff-profile-ready") {
            this.decorations.delete(row); changed = true;
          } else if (target.closest(".name, .country-box") || mutation.type === "childList") {
            if (mutation.type === "childList" && target.closest(".avatar-img") &&
                [...mutation.addedNodes, ...mutation.removedNodes].every(node => node.nodeType !== Node.ELEMENT_NODE || node.matches(".lff-bell-dot"))) continue;
            this.rowData.delete(row); this.decorations.delete(row);
            this.countriesDirty = true; changed = true;
          }
        } else if (mutation.type === "childList") {
          this.rows = null; this.countriesDirty = true; changed = true;
        } else if (mutation.attributeName === "data-lff-loading") {
          changed = true;
        }
      }
      return changed;
    }

    mount() {
      if (this.isBell) {
        if (this.list.firstElementChild !== this.host) this.list.prepend(this.host);
        return;
      }
      const header = Array.from(this.list.children).find(el => el.classList.contains("fliter-box"));
      if (this.header && this.header !== header) this.header.removeAttribute("data-lff-toolbar");
      this.header = header || null;
      if (header) {
        header.setAttribute("data-lff-toolbar", "true");
        this.host.toggleAttribute("data-bell-space", Boolean(header.querySelector(".ico-remind")));
        if (this.host.parentElement !== header) header.append(this.host);
      } else if (!this.list.contains(this.host)) {
        const wrap = Array.from(this.list.children).find(el => el.classList.contains("list-wrap"));
        this.list.insertBefore(this.host, wrap || null);
      }
    }

    update() {
      if (!this.list.isConnected) return;
      this.invalidate(this.observer.takeRecords());
      this.mount();
      if (!this.rows) {
        this.rows = Array.from(this.list.querySelectorAll(this.isBell ? ":scope > .ocell" : ROW_SELECTOR));
        this.sections = Array.from(this.list.querySelectorAll(".flist-box > .sort-title"), heading => {
          const rows = []; let sibling = heading.nextElementSibling;
          while (sibling && !sibling.classList.contains("sort-title")) {
            if (sibling.matches(".ocell")) rows.push(sibling);
            sibling = sibling.nextElementSibling;
          }
          return { heading, rows };
        });
      }
      const rows = this.rows;
      const onlineFlag = settings.onlineOnly ? "true" : "false";
      if (this.list.getAttribute("data-lff-online-only") !== onlineFlag) {
        this.list.setAttribute("data-lff-online-only", onlineFlag);
      }
      const favoriteFlag = String(settings.favoritesOnly);
      if (this.list.getAttribute("data-lff-favorites-only") !== favoriteFlag) {
        this.list.setAttribute("data-lff-favorites-only", favoriteFlag);
      }
      const countrySignature = JSON.stringify(settings.countries);
      if (this.lastFavorites !== settings.favoritesOnly || this.lastCountries !== countrySignature) {
        this.countriesDirty = true;
        this.lastFavorites = settings.favoritesOnly; this.lastCountries = countrySignature;
      }
      if (this.isBell) for (const row of rows) this.enhanceBellRow(row);
      let shown = 0;
      let online = 0;
      let total = 0;
      const query = Core.searchKey(this.query, this.language);
      if (this.countriesDirty) this.countries.clear();
      for (const row of rows) {
        let friend = this.rowData.get(row);
        if (!friend) {
          friend = Core.readFriend(row);
          friend.searchName = Core.searchKey(friend.name, this.language);
          this.rowData.set(row, friend);
        }
        if (this.onlineDirty.delete(row)) friend.online = Core.readOnline(row);
        if (this.favoriteDirty.delete(row)) friend.favorite = row.getAttribute("data-lff-favorite") === "true";
        if (this.ageDirty.delete(row)) friend.age = Core.readAge(row);
        const eligible = !settings.favoritesOnly || friend.favorite;
        total += Number(eligible);
        const matches = Core.matchesFriend(friend, settings, query, this.language, true);
        shown += Number(matches);
        online += Number(eligible && friend.online);
        if (this.matches.get(row) !== matches) {
          setHidden(row, !matches); this.matches.set(row, matches);
        }
        if (this.countriesDirty && eligible) this.countries.set(friend.countryKey,
          friend.countryLabel || Core.countryLabel(friend.countryKey, this.language) || this.t.unknown);
      }
      for (const dirty of [this.onlineDirty, this.favoriteDirty, this.ageDirty]) {
        for (const row of dirty) if (!this.list.contains(row)) dirty.delete(row);
      }
      // Livu puts section headings and rows beside each other (e.g. Favorites).
      for (const section of this.sections) {
        setHidden(section.heading, section.rows.length > 0 && !section.rows.some(row => this.matches.get(row)));
      }
      if (this.countriesDirty) {
        for (const country of settings.countries) if (!this.countries.has(country)) {
          this.countries.set(country, Core.countryLabel(country, this.language) || this.t.unknown);
        }
        this.choices = Array.from(this.countries, ([key, label]) => ({ key, label }))
          .sort((a, b) => Core.compareCountries(a, b, this.language));
        const signature = JSON.stringify(this.choices);
        if (signature !== this.optionSignature) {
          this.ui.countryOptions.replaceChildren(...this.choices.map(item => {
            const button = document.createElement("button"), text = document.createElement("span"), check = document.createElement("span");
            button.type = "button"; button.dataset.country = item.key; button.setAttribute("aria-pressed", "false");
            text.textContent = item.label; check.className = "check"; check.setAttribute("aria-hidden", "true");
            button.append(text, check); return button;
          }));
          this.optionSignature = signature;
        }
        this.countriesDirty = false;
      }
      const selectedCountries = new Set(settings.countries);
      for (const button of this.ui.countryOptions.querySelectorAll("button[data-country]")) {
        const selected = selectedCountries.has(button.dataset.country);
        button.setAttribute("aria-pressed", String(selected));
        button.querySelector(".check").textContent = selected ? "✓" : "";
      }
      this.ui.allCountries.disabled = settings.countries.length === 0;
      this.ui.countryToggle.querySelector("span").textContent = settings.countries.length
        ? this.t.countryCount(settings.countries.length) : this.t.nationality;
      this.ui.countryToggle.title = settings.countries.length
        ? this.choices.filter(item => selectedCountries.has(item.key)).map(item => item.label).join(", ") : this.t.all;
      this.ui.ageToggle.querySelector("span").textContent = settings.ageMin != null || settings.ageMax != null
        ? `${settings.ageMin ?? "…"}–${settings.ageMax ?? "…"}` : this.t.ageRange;
      // Storage and status updates can arrive while an age value is still a
      // draft. Keep the focused portal input intact; its change handler commits
      // the draft, after which blur restores the normalized saved value.
      if (this.menuShadow.activeElement !== this.ui.minAge) this.ui.minAge.value = settings.ageMin ?? "";
      if (this.menuShadow.activeElement !== this.ui.maxAge) this.ui.maxAge.value = settings.ageMax ?? "";
      this.ui.includeUnknown.setAttribute("aria-checked", String(settings.includeUnknownAge));
      this.renderMenus();
      this.ui.favorites.setAttribute("aria-checked", favoriteFlag);
      this.ui.online.setAttribute("aria-checked", String(settings.onlineOnly));
      this.ui.clear.hidden = !this.query;
      const countText = this.t.count(shown, total);
      if (this.ui.count.textContent !== countText) this.ui.count.textContent = countText;
      const loading = this.list.getAttribute("data-lff-loading");
      this.ui.summary.title = loading === "loading" ? this.t.loading : loading === "error" ? this.t.loadError
        : settings.favoritesOnly ? this.t.favoritesLoaded : loading === "complete" ? this.t.loaded : this.t.manual;
      this.ui.more.hidden = this.isBell || settings.favoritesOnly || loading !== "manual";
      this.ui.summary.setAttribute("aria-busy", String(loading === "loading"));
      this.ui.progress.hidden = loading !== "loading" && loading !== "error";
      this.ui.progress.classList.toggle("error", loading === "error");
      this.ui.progress.textContent = loading === "error" ? "!" : "";
      this.ui.empty.hidden = shown > 0 || loading === "loading";
      this.ui.notice.hidden = !saveFailed;
      this.ui.notice.textContent = saveFailed ? this.t.session : "";
      this.report = { loaded: total, shown, online, countries: this.choices, language: this.language, loading };
    }

    enhanceBellRow(row) {
      if (!this.originalRowAttributes.has(row)) {
        this.originalRowAttributes.set(row, Object.fromEntries(["role", "tabindex", "title", "aria-label"]
          .map(key => [key, row.getAttribute(key)])));
      }
      const status = row.getAttribute("data-lff-status");
      const signature = `${status}|${row.getAttribute("data-lff-profile-ready")}|${row.querySelector(".name")?.textContent}`;
      if (this.decorations.get(row) === signature) return;
      this.decorations.set(row, signature);
      const state = status === "2" ? "online" : status === "1" ? "unavailable" : status === "0" ? "offline" : "unknown";
      const label = state === "online" ? this.t.statusOnline : state === "unavailable" ? this.t.statusUnavailable
        : state === "offline" ? this.t.statusOffline : this.t.statusUnknown;
      const avatar = row.querySelector(".avatar-img");
      let dot = avatar?.querySelector(".lff-bell-dot");
      if (avatar && !dot) {
        dot = document.createElement("span");
        dot.className = "lff-bell-dot";
        dot.setAttribute("aria-hidden", "true");
        avatar.append(dot);
      }
      if (dot) { dot.dataset.state = state; dot.title = label; }
      row.setAttribute("data-lff-decorated", "true");
      const ready = row.getAttribute("data-lff-profile-ready") === "true";
      if (ready) {
        row.setAttribute("role", "button");
        row.setAttribute("tabindex", "0");
        row.setAttribute("title", `${this.t.openProfile} · ${label}`);
        row.setAttribute("aria-label", `${this.t.openProfile}: ${row.querySelector(".name")?.textContent.trim() || ""}. ${label}`);
      } else {
        const original = this.originalRowAttributes.get(row);
        for (const key of ["role", "tabindex", "aria-label"]) {
          if (original[key] == null) row.removeAttribute(key); else row.setAttribute(key, original[key]);
        }
        row.setAttribute("title", this.t.profileWaiting);
      }
    }

    destroy() {
      clearTimeout(this.timer);
      this.observer.disconnect();
      this.callObserver.disconnect();
      document.removeEventListener("pointerdown", this.outsideClick, true);
      document.removeEventListener("keydown", this.escapeKey, true);
      document.removeEventListener("scroll", this.repositionMenus, true);
      window.removeEventListener("resize", this.repositionMenus);
      for (const element of this.list.querySelectorAll("[data-lff-hidden]")) setHidden(element, false);
      this.list.removeAttribute("data-lff-online-only");
      this.list.removeAttribute("data-lff-favorites-only");
      this.onlineDirty.clear(); this.favoriteDirty.clear(); this.ageDirty.clear();
      this.header?.removeAttribute("data-lff-toolbar");
      for (const row of this.list.querySelectorAll("[data-lff-decorated]")) {
        const original = this.originalRowAttributes.get(row);
        if (original) for (const [key, value] of Object.entries(original)) {
          if (value == null) row.removeAttribute(key); else row.setAttribute(key, value);
        }
        row.removeAttribute("data-lff-decorated");
        for (const element of row.querySelectorAll(".lff-bell-dot, .lff-bell-status")) element.remove();
      }
      this.host.remove();
      this.menuPortal.remove();
    }
  }

  function reconcile() {
    reconcileTimer = null;
    if (!initialized) return;
    for (const [list, controller] of controllers) {
      if (!list.isConnected) { controller.destroy(); controllers.delete(list); }
    }
    for (const list of document.querySelectorAll(LIST_SELECTOR)) {
      if (!controllers.has(list) && (list.closest(".im-online") || list.querySelector(".list-wrap"))) {
        controllers.set(list, new FilterPanel(list));
      }
    }
  }

  function scheduleReconcile() {
    if (reconcileTimer == null) reconcileTimer = setTimeout(reconcile, 90);
  }

  const lifecycleObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      const pendingList = mutation.target.nodeType === Node.ELEMENT_NODE
        ? mutation.target.closest(LIST_SELECTOR) : mutation.target.parentElement?.closest(LIST_SELECTOR);
      if (pendingList && !controllers.has(pendingList)) {
        scheduleReconcile(); return;
      }
      for (const node of [...mutation.addedNodes, ...mutation.removedNodes]) {
        if (node.nodeType === Node.ELEMENT_NODE &&
            (node.matches(LIST_SELECTOR) || node.querySelector(LIST_SELECTOR))) {
          scheduleReconcile(); return;
        }
      }
    }
  });
  lifecycleObserver.observe(document.documentElement, { subtree: true, childList: true });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[Core.STORAGE_KEY]) return;
    settings = Core.normalizeSettings(changes[Core.STORAGE_KEY].newValue);
    for (const controller of controllers.values()) controller.update();
  });

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== "LFF_STATUS" || sender.id !== chrome.runtime.id) return;
    const available = Array.from(controllers.values()).filter(panel => panel.list.isConnected);
    const controller = available.find(panel => panel.isBell && panel.list.getBoundingClientRect().width > 0)
      || available.find(panel => panel.list.getBoundingClientRect().width > 0) || available[0];
    if (controller) controller.update();
    respond({ settings, active: Boolean(controller), ...controller?.report });
  });

  chrome.storage.local.get(Core.STORAGE_KEY).then(result => {
    settings = Core.normalizeSettings(result[Core.STORAGE_KEY]);
  }).catch(() => { saveFailed = true; }).finally(() => {
    initialized = true; reconcile();
  });
})();
