Version 2.1.13 combines contacts sync and online status in one sticky **Refresh** button. Contacts default to **Online only**; compact cards show country beside the name and smaller action buttons. **Auto-approve Selam coins** is off by default and saved on this device. When enabled, clicking Send selam skips the batch popup and may spend 9 coins per paid chat. Existing sender, cost-change and duplicate-send checks remain. Android behavior is unchanged.

Version 2.1.12 shows gift status as a compact symbol beside coins: gift = can send, blocked = cannot send, ? = unknown or not tested. Hover for the recorded Notion details.

Version 2.1.11 removes automatic password prompts, reuses the Contacts Notion connection for Autofill unless disconnected, and shows the private account list’s **Gift test** status in Autofill cards and email suggestions. Refresh coins to update recorded gift status.

Version 2.1.10 added **Select top 5** before **Select top 20**. Both use the current search, sort and Online only filter.

 LivU Helper for Chrome · 2.1.13

Version 2.1.9 adds a **+** icon to the compact hover toolbar, including the small conversation avatars. Click it to save that contact without changing pages. Saving and already-saved state are shared with the larger profile card.

Version 2.1.5 accompanies the Android task-handling update; Chrome functionality is unchanged from 2.1.4.

This combines Friends Filters with the contacts, account picker, Notion sync and greetings used by Safari. Both browsers are generated from `helper-shared/`. Android uses the same private account and contact lists.

Version 2.1.4 reads the selected account’s **Password** text field from private Notion. Choose an account from the email dropdown and press Next; its password fills without a password popup. Browser passwords stay only briefly in tab memory, outside saved lists and backups. Editing the email cancels automatic filling; existing passwords, signup and verification screens stay untouched. The helper never presses Sign in. Tests cover account switching and cancellation on synthetic pages.

## Install or update

This version includes **Helper updates** in the extension popup and the webpage Contacts/Autofill settings. Press **Check for updates**; a newer version offers its Chrome ZIP. Replace the files in the original extension folder, Reload it at `chrome://extensions`, then reload LivU. Keep the same folder and extension entry to preserve saved data. Unpacked extensions cannot silently replace their own files. The code-only update channel is published at `https://github.com/rafadan2/livu-helper-updates`; the Chrome update broker was verified with the previous release. Version 2.1.4 adds synthetic Notion-password regression checks. This check sends no Notion token or saved records.

Extract `LivU-Chrome-Helper-2.1.13.zip`. Replace files in the **original installed extension folder**, open `chrome://extensions`, click **Reload**, then reload LivU. Its new name is **LivU Helper**. Keep the original folder and extension entry to preserve settings; avoid a second copy.

For first installation, enable **Developer mode**, choose **Load unpacked** and select the extracted folder containing `manifest.json`. Keep that folder permanently.

## Contacts, accounts and greetings

- Press the floating **+** on a person's profile to save its visible name/link quietly, keeping your current messages/contacts view. **Contacts** opens the shared list. Add/edit by link and notes are also available.
- Connect the existing private Notion Contacts list through **Contacts** and Accounts through **Autofill → Account setup & sync**. Each panel shows connection health and refresh times. Enter tokens directly on the device.
- **Autofill** and the dropdown arrow inside the email field show account numbers, email addresses and recorded coins. Type in the email field to filter the dropdown. Connect Notion or import your own private `accounts.json`. GitHub downloads contain no account snapshot. With account Notion connected, the selected account’s Password text field is read automatically and held briefly in tab memory. There is no password popup. Missing/empty passwords show an error; offline lists can still use a manually entered tab password. Press Next and the password fills automatically, without another account selection. Press LivU's sign-in button yourself. **Autofill → Account setup & sync → Forget password** clears the helper's password and pending fill. The pending step expires after two minutes; you can still choose **Fill #N** on the password screen.
- Search/sort Contacts, use **Online only**, then **Select all**, **Select top 5** or **Select top 20**. Status is a snapshot expiring after two minutes. Selection does not send messages.
- **Send selam** processes selected contacts with the signed-in account. It checks the selected chats first, then shows one approval with the contact count and total cost: free chats add 0 coins and paid chats add 9 each. Cancel sends nothing. Chats that become paid after approval are skipped. Uncertain results are held for checking. Drafts, active calls and sender changes stop unsafe actions.

Contacts refresh when opened, manually synced or edited. Accounts refresh when Autofill opens or **Refresh coins** is tapped. Failures keep cached rows. Balances are metadata/Notion snapshots. Account passwords come from private Notion; browser copies are not cached. Pins, filters and greeting history stay on each device.

## Friend tools

Open LivU's Friends or bell list. **Favorites**, **Online**, multi-country, age and name filters work together. Unknown ages are included by default. More regular friends load only through the list's **+**, separate from the floating save-contact **+**.

Hover a loaded person/conversation for available profile/photo previews, copy, message, native favorite/rename, pin and video actions. These use LivU's own controls and keep their usual behavior and costs. Pins stay local and are scoped to the signed-in account where LivU supplies its ID. The pinned sidebar preserves the loaded list and scroll for the page session, stepping aside during calls.

During an active video call, the phrase panel **copies** phrases without typing or sending them. The extension popup holds friend filter settings; Contacts and Autofill appear on the LivU page.

## Privacy and updates

Runs on HTTPS LivU pages. Chrome storage holds contact/account caches, Notion connections, settings, pins and action history. Login passwords are fetched from the selected Notion row and stay only briefly in tab memory for a one-use fill; they never enter persistent Chrome storage or backups. The worker accepts only this extension's top-level LivU pages, sends Notion requests only to its fixed HTTPS API and executes packaged page code. No analytics, payment details or passwords are bundled.

Copy a contacts backup before clearing storage. Notion deletions do not remove browser cached contacts; pending local edits take priority. Opening the list on another device refreshes its data. Updating code requires replacing/reloading each installed package.

See included **SYNC.md** for refresh timing and the shared release process. Automated checks and local dummy previews pass; live behavior still needs checking in your installation.
