(() => {
  "use strict";
  if (window.__lffCallPhrases) return;
  window.__lffCallPhrases = true;

  const groups = [
    { key: "greetings", en: "Greetings", tr: "Selamlaşma", phrases: [
      "hi bb", "Hey beautiful 😘", "How are you?", "Where are you from?", "Nice to meet you bb"
    ] },
    { key: "questions", en: "Questions", tr: "Sorular", phrases: [
      "How old are you?", "What's your name?", "Do you speak English?", "Do you play?", "Are you alone?", "What are you doing bb?"
    ] },
    { key: "flirting", en: "Flirting", tr: "Flört", phrases: [
      "You look very pretty", "You have a beautiful smile", "I like your eyes 😍", "You're so cute bb", "You look so sexy", "I like what I see 😘"
    ] },
    { key: "encouraging", en: "Encouraging", tr: "Teşvik", phrases: [
      "Show me bb 😘", "Show me more bb", "Take it off bb", "Don't be shy bb", "Keep going bb", "Turn around bb", "Come closer bb", "I wanna see more 😍", "That's it bb", "You look amazing bb"
    ] }
  ];
  const root = document.documentElement;
  let current = null;

  function isVisible(element) {
    if (!element?.isConnected) return false;
    const style = getComputedStyle(element), rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity) > 0.01 &&
      rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 && rect.left < innerWidth && rect.top < innerHeight;
  }
  function activeSession() {
    if (document.hidden || document.visibilityState !== "visible" || root.getAttribute("data-lff-video-chat-active") !== "true") return "";
    const session = root.getAttribute("data-lff-video-chat-session") || "";
    return session && isVisible(document.querySelector(".base-video-chat.video-chat")) ? session : "";
  }
  function language() {
    let requested = document.documentElement.lang || document.documentElement.getAttribute("lang") || "";
    try { requested ||= localStorage.getItem("siteLanguage") || ""; } catch { /* Use English if page storage is unavailable. */ }
    return /^tr(?:-|$)/i.test(requested) ? "tr" : "en";
  }
  function isCurrent(instance) {
    return current === instance && instance.host.isConnected && activeSession() === instance.session;
  }
  function removePanel() {
    if (!current) return;
    clearTimeout(current.feedbackTimer);
    current.host.remove();
    current = null;
  }
  function mount(session) {
    removePanel();
    const tr = language() === "tr";
    const host = document.createElement("div");
    host.id = "lff-video-phrases";
    host.setAttribute("data-lff-owned", "call-phrases");
    host.style.cssText = "position:fixed;right:12px;bottom:96px;z-index:2147483000;display:block;width:min(318px,calc(100vw - 16px));max-height:calc(100dvh - 108px);font:13px/1.35 Arial,sans-serif;color:#302344;pointer-events:auto;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host{all:initial;color:#302344;font:13px/1.35 Arial,sans-serif}
        *{box-sizing:border-box}
        .panel{max-height:min(48vh,420px);max-height:min(48dvh,420px);display:flex;flex-direction:column;overflow:hidden;border:1px solid #e4d8f7;border-radius:13px;background:rgba(255,255,255,.98);box-shadow:0 8px 28px rgba(35,20,55,.24);}
        header{display:flex;align-items:center;gap:8px;padding:9px 10px;background:linear-gradient(105deg,#8054cf,#6332ae);color:#fff;font-weight:700;}
        .title{flex:1;letter-spacing:.1px}
        button{font:inherit;cursor:pointer}
        .collapse{width:27px;height:25px;padding:0;border:1px solid rgba(255,255,255,.45);border-radius:7px;background:rgba(255,255,255,.14);color:#fff;font-size:18px;line-height:20px}
        button:focus-visible,summary:focus-visible,textarea:focus-visible{outline:2px solid #ffdb73;outline-offset:2px}
        .body{padding:5px 8px 8px;overflow:auto;overscroll-behavior:contain;}
        details{border-bottom:1px solid #eee8f6}
        details:last-of-type{border-bottom:0}
        summary{display:flex;align-items:center;gap:6px;min-height:30px;padding:3px 2px;color:#5d388e;font-weight:700;cursor:pointer;list-style:none}
        summary::-webkit-details-marker{display:none}
        summary::before{content:"›";display:inline-block;width:11px;color:#8b69b6;font-size:17px;line-height:12px;transform:rotate(0deg);transition:transform .12s}
        details[open] summary::before{transform:rotate(90deg)}
        .count{margin-left:auto;color:#927da9;font-size:11px;font-weight:500}
        .phrases{display:grid;gap:4px;padding:0 0 7px 16px}
        .phrase{display:flex;align-items:center;gap:7px;min-height:30px;padding:3px 4px 3px 7px;border-radius:8px;background:#f8f5fc}
        .text{flex:1;min-width:0;overflow-wrap:anywhere;color:#342747}
        .copy{flex:none;min-width:52px;min-height:25px;padding:3px 8px;border:0;border-radius:7px;background:#eee4fb;color:#6033a6;font-size:11px;font-weight:700}
        .copy:hover{background:#e2d0f7}
        .status{min-height:0;padding:0 10px;color:#5e4880;font-size:11px}
        .status:not(:empty){padding-top:5px;padding-bottom:7px}
        .manual{display:none;width:calc(100% - 16px);height:42px;margin:3px 8px 8px;padding:5px 7px;resize:none;border:1px solid #bda5dd;border-radius:7px;background:#fff;color:#302344;font:12px/1.25 Arial,sans-serif;user-select:text}
        .panel.collapsed .body,.panel.collapsed .status,.panel.collapsed .manual{display:none!important}
        @media(max-width:420px){:host{right:8px!important;bottom:94px!important;width:min(294px,calc(100vw - 16px))!important}.panel{max-height:min(42dvh,300px)}header{padding:7px 9px}.body{padding:3px 7px 6px}.phrase{min-height:28px}}
        @media(max-height:460px){:host{bottom:82px!important;max-height:calc(100dvh - 92px)!important}.panel{max-height:min(40dvh,220px)}}
      </style>
      <section class="panel" role="region" aria-label="${tr ? "Hızlı ifadeler" : "Quick phrases"}">
        <header><span class="title">${tr ? "Hızlı ifadeler" : "Quick phrases"}</span><button class="collapse" type="button" aria-expanded="true" aria-label="${tr ? "Daralt" : "Collapse"}" title="${tr ? "Daralt" : "Collapse"}">−</button></header>
        <div class="body"></div><div class="status" role="status" aria-live="polite"></div>
        <textarea class="manual" readonly aria-label="${tr ? "Elle kopyalamak için ifade" : "Phrase to copy manually"}"></textarea>
      </section>`;
    const panel = shadow.querySelector(".panel"), body = shadow.querySelector(".body");
    const status = shadow.querySelector(".status"), manual = shadow.querySelector(".manual"), collapse = shadow.querySelector(".collapse");
    const instance = { host, shadow, session, panel, status, manual, collapse, feedbackButton: null, feedbackTimer: 0, requestId: 0 };
    for (const group of groups) {
      const details = document.createElement("details");
      details.dataset.category = group.key;
      if (group.key === "greetings") details.open = true;
      const summary = document.createElement("summary"), label = document.createElement("span"), count = document.createElement("span");
      label.textContent = tr ? group.tr : group.en;
      count.className = "count"; count.textContent = String(group.phrases.length);
      summary.append(label, count);
      const list = document.createElement("div"); list.className = "phrases";
      for (const phrase of group.phrases) {
        const row = document.createElement("div"); row.className = "phrase";
        const text = document.createElement("span"); text.className = "text"; text.textContent = phrase;
        const copy = document.createElement("button"); copy.className = "copy"; copy.type = "button";
        copy.textContent = tr ? "Kopyala" : "Copy";
        copy.setAttribute("aria-label", `${tr ? "Kopyala" : "Copy"}: ${phrase}`);
        copy.addEventListener("click", event => copyPhrase(instance, phrase, copy, event));
        row.append(text, copy); list.append(row);
      }
      details.append(summary, list); body.append(details);
    }
    collapse.addEventListener("click", event => {
      if (!event.isTrusted || !isCurrent(instance)) return;
      setCollapsed(instance, !panel.classList.contains("collapsed"), tr);
    });
    // This UI is body-mounted outside Livu's panel. Keep its pointer and click
    // events from reaching the site's bubble-phase clickoutside handlers.
    for (const name of ["pointerdown", "pointerup", "mousedown", "mouseup", "click", "dblclick", "contextmenu", "touchstart", "touchend", "wheel", "keydown", "keyup"]) {
      host.addEventListener(name, event => event.stopPropagation());
    }
    host.addEventListener("keydown", event => {
      if (event.isTrusted && event.key === "Escape" && isCurrent(instance)) {
        event.preventDefault();
        if (!panel.classList.contains("collapsed")) setCollapsed(instance, true, tr);
        instance.collapse.focus({ preventScroll: true });
      }
    });
    current = instance;
    document.body.append(host);
  }
  function copyPhrase(instance, phrase, button, event) {
    if (!event.isTrusted || !isCurrent(instance)) return;
    event.preventDefault();
    const requestId = ++instance.requestId;
    clearTimeout(instance.feedbackTimer);
    if (instance.feedbackButton && instance.feedbackButton !== button) {
      instance.feedbackButton.textContent = language() === "tr" ? "Kopyala" : "Copy";
    }
    instance.feedbackButton = button;
    instance.status.textContent = "";
    instance.manual.style.display = "none";
    instance.manual.value = "";
    button.textContent = language() === "tr" ? "Kopyala" : "Copy";
    let write;
    try {
      // Keep the clipboard request synchronous with the trusted button click.
      write = navigator.clipboard?.writeText(phrase);
      if (!write || typeof write.then !== "function") throw new Error("Clipboard unavailable");
    } catch {
      showCopyFailure(instance, phrase, button, requestId);
      return;
    }
    Promise.resolve(write).then(() => {
      if (!isCurrent(instance) || instance.requestId !== requestId) return;
      button.textContent = language() === "tr" ? "Kopyalandı" : "Copied";
      instance.status.textContent = language() === "tr" ? "Kopyalandı" : "Copied";
      instance.feedbackTimer = setTimeout(() => {
        if (!isCurrent(instance) || instance.requestId !== requestId) return;
        button.textContent = language() === "tr" ? "Kopyala" : "Copy";
        instance.status.textContent = "";
        instance.feedbackButton = null;
      }, 1400);
    }).catch(() => showCopyFailure(instance, phrase, button, requestId));
  }
  function setCollapsed(instance, collapsed, tr) {
    instance.panel.classList.toggle("collapsed", collapsed);
    instance.collapse.textContent = collapsed ? "+" : "−";
    instance.collapse.setAttribute("aria-expanded", String(!collapsed));
    instance.collapse.setAttribute("aria-label", collapsed ? (tr ? "Genişlet" : "Expand") : (tr ? "Daralt" : "Collapse"));
    instance.collapse.title = instance.collapse.getAttribute("aria-label");
  }
  function showCopyFailure(instance, phrase, button, requestId) {
    if (!isCurrent(instance) || instance.requestId !== requestId) return;
    instance.feedbackButton = button;
    button.textContent = language() === "tr" ? "Yeniden dene" : "Try again";
    instance.status.textContent = language() === "tr" ? "Elle kopyalamak için ifadeyi seçin" : "Select the phrase to copy it manually";
    instance.manual.value = phrase;
    instance.manual.style.display = "block";
    instance.manual.focus();
    instance.manual.select();
  }
  function reconcile() {
    const session = activeSession();
    if (!session) { removePanel(); return; }
    if (current && current.session === session && current.host.isConnected) return;
    mount(session);
  }
  const observer = new MutationObserver(records => {
    const callSignalChanged = records.some(record => record.type === "attributes" &&
      record.target === root && (record.attributeName === "data-lff-video-chat-active" || record.attributeName === "data-lff-video-chat-session"));
    if (callSignalChanged || (current && records.some(record => record.type === "childList"))) reconcile();
  });
  observer.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["data-lff-video-chat-active", "data-lff-video-chat-session"] });
  document.addEventListener("visibilitychange", reconcile);
  window.addEventListener("pagehide", removePanel);
  window.addEventListener("pageshow", reconcile);
  reconcile();
})();
