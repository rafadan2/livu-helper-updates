(() => {
  "use strict";

  const STORAGE_KEY = "livuFriendFilters";
  const DEFAULTS = Object.freeze({ favoritesOnly: true, onlineOnly: false, countries: [],
    ageMin: null, ageMax: null, includeUnknownAge: true, sidebarPinned: true });

  function validCountry(value) {
    return typeof value === "string" && /^(?:[a-z]{2}|unknown|name:.{1,90})$/u.test(value);
  }

  function validAge(value) {
    const age = typeof value === "number" ? value
      : typeof value === "string" && /^\d{1,3}$/.test(value) ? Number(value) : NaN;
    return Number.isSafeInteger(age) && age >= 18 && age <= 120 ? age : null;
  }

  function ageFromBirthday(value, now = new Date()) {
    if (value instanceof Date) return ageOn(value, now);
    let date = null;
    if (typeof value === "number" && Number.isFinite(value) && value !== 0) {
      if (Number.isInteger(value) && value >= 19000101 && value <= 20991231) {
        const text = String(value);
        date = strictDate(text.slice(0, 4), text.slice(4, 6), text.slice(6, 8));
      } else {
        // Livu's public profile detail supplies birthday as milliseconds.
        if (value <= now.getTime()) date = new Date(value);
      }
    } else if (typeof value === "string") {
      const text = value.trim();
      let match = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(text);
      if (match) date = strictDate(match[1], match[2], match[3]);
      else if ((match = /^(\d{4})(\d{2})(\d{2})$/.exec(text))) date = strictDate(match[1], match[2], match[3]);
      else if (/^-?\d{10,13}$/.test(text) && Number(text) !== 0) {
        const stamp = Number(text);
        if (stamp <= now.getTime()) date = new Date(stamp);
      }
    }
    return date ? ageOn(date, now) : null;
  }

  function strictDate(year, month, day) {
    const y = Number(year), m = Number(month), d = Number(day);
    const date = new Date(y, m - 1, d);
    return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d ? date : null;
  }

  function ageOn(birthday, now) {
    if (!Number.isFinite(birthday.getTime()) || birthday.getTime() > now.getTime()) return null;
    let age = now.getFullYear() - birthday.getFullYear();
    if (now.getMonth() < birthday.getMonth() ||
        (now.getMonth() === birthday.getMonth() && now.getDate() < birthday.getDate())) age--;
    return age >= 18 && age <= 120 ? age : null;
  }

  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    const result = { ...DEFAULTS };
    if (typeof source.favoritesOnly === "boolean") result.favoritesOnly = source.favoritesOnly;
    if (typeof source.sidebarPinned === "boolean") result.sidebarPinned = source.sidebarPinned;
    // Keep the visible behavior when migrating the old pause/country switches.
    if (source.enabled === false) return result;
    if (typeof source.onlineOnly === "boolean") result.onlineOnly = source.onlineOnly;
    const countries = Array.isArray(source.countries) ? source.countries
      : typeof source.country === "string" && source.countryEnabled !== false ? [source.country] : [];
    result.countries = [...new Set(countries.filter(validCountry))].slice(0, 100);
    const minimum = validAge(source.ageMin), maximum = validAge(source.ageMax);
    result.ageMin = minimum;
    result.ageMax = minimum != null && maximum != null && maximum < minimum ? minimum : maximum;
    if (typeof source.includeUnknownAge === "boolean") result.includeUnknownAge = source.includeUnknownAge;
    return result;
  }

  function readAge(row) {
    const value = row.getAttribute("data-lff-age");
    return value == null ? null : validAge(value);
  }

  function readFriend(row) {
    // Use Livu's country field, never a flag or country in a person's nickname.
    const countryElement = row.querySelector(".country-box .country-name");
    const countryLabel = (countryElement?.textContent || "").trim();
    const flag = row.querySelector(".country-box .flag");
    const flagSource = flag?.getAttribute("src") || "";
    const code = flagSource.match(/\/countryFlag\/([a-z]{2})\.(?:png|svg|webp)(?:[?#]|$)/i);
    const countryKey = code ? code[1].toLowerCase() : countryLabel
      ? `name:${countryLabel.normalize("NFKC").toLowerCase().replace(/\s+/gu, " ").slice(0, 90)}`
      : "unknown";
    return { online: readOnline(row), countryKey, countryLabel, age: readAge(row),
      favorite: row.getAttribute("data-lff-favorite") === "true", name: row.querySelector(".name")?.textContent.trim() || "" };
  }

  function readOnline(row) {
    return row.closest(".im-online") ? row.getAttribute("data-lff-status") === "2"
      : Boolean(row.querySelector(".online-status")?.classList.contains("s-2"));
  }

  function searchKey(value, language = "en") {
    return String(value).normalize("NFKC").toLocaleLowerCase(language).trim().replace(/\s+/gu, " ");
  }

  function matchesFriend(friend, settings, query = "", language = "en", prepared = false) {
    if (settings.favoritesOnly && !friend.favorite) return false;
    if (settings.onlineOnly && !friend.online) return false;
    if (settings.countries?.length && !settings.countries.includes(friend.countryKey)) return false;
    if (settings.ageMin != null || settings.ageMax != null) {
      if (friend.age == null) { if (!settings.includeUnknownAge) return false; }
      else if ((settings.ageMin != null && friend.age < settings.ageMin) ||
          (settings.ageMax != null && friend.age > settings.ageMax)) return false;
    }
    if (query && !(friend.searchName ?? searchKey(friend.name, language)).includes(prepared ? query : searchKey(query, language))) return false;
    return true;
  }

  function countryLabel(key, language = "en") {
    if (/^[a-z]{2}$/.test(key)) {
      try {
        return new Intl.DisplayNames([language], { type: "region" }).of(key.toUpperCase());
      } catch { return key.toUpperCase(); }
    }
    return key.startsWith("name:") ? key.slice(5) : "";
  }

  function compareCountries(a, b, language = "en") {
    const isTurkiye = item => item.key === "tr" || /^name:(?:türkiye|turkiye|turkey)$/iu.test(item.key);
    return Number(isTurkiye(b)) - Number(isTurkiye(a)) || a.label.localeCompare(b.label, language);
  }

  const TRANSLATIONS = {
    en: {
      title: "Friends filters", online: "Online", onlineHint: "Show only online friends",
      favorites: "Favorites", favoritesHint: "Show only favorites", favoritesLoaded: "Loaded favorites",
      more: "Load 100 more friends", manual: "More friends load only when you press +",
      nationality: "Country", all: "All countries", unknown: "Unknown country",
      countryCount: count => `${count} countries`, ageRange: "Age", minAge: "Min", maxAge: "Max",
      includeUnknownAge: "Include unknown ages", ageHint: "Some profiles don’t show an age",
      search: "Search", clear: "Clear search", reset: "Reset filters",
      loading: "Loading…", loaded: "All friends loaded", partial: "Loaded friends",
      loadError: "Loading stopped. Refresh Livu to retry.", noMatches: "No matches",
      count: (shown, total) => `${shown} / ${total}`,
      popupTitle: "Livu filters", waiting: "Open your friends list on Livu.", open: "Open Livu",
      refresh: "Refresh Livu after installing or updating the extension.",
      session: "Preferences could not be saved.",
      statusOnline: "Online", statusUnavailable: "Unavailable", statusOffline: "Offline",
      statusUnknown: "Status unavailable", statusHint: "Status from Livu; refreshes while this list is open",
      openProfile: "Open profile", profileWaiting: "Profile link is not available yet",
      copyLink: "Copy profile link", copied: "Link copied", videoCall: "Video call", message: "Message",
      addFavorite: "Add to favorites", removeFavorite: "Remove from favorites", rename: "Rename",
      addContact: "Add to contacts", inContacts: "✓ In contacts", savingContact: "Saving…", contactSaved: "Contact saved. Notion sync runs when connected.",
      pinPerson: "Pin person", unpinPerson: "Unpin person", pinConversation: "Pin conversation", unpinConversation: "Unpin conversation",
      save: "Save", cancel: "Cancel", close: "Close", pin: "Keep sidebar open", unpin: "Unpin sidebar",
      actionFailed: "Couldn't complete this action", unavailable: "This action isn't available yet",
      profileLoading: "Loading profile…", profileUnavailable: "Open the profile for more details",
      saved: "Saved", copyManually: "Copy this link", renameUnavailable: "This entry is no longer available", age: "Age",
      photos: "Profile photos", previousPhoto: "Previous photo", nextPhoto: "Next photo",
      photosLoading: "Loading photos…", photosUnavailable: "Open the profile to see its photos",
      photoCount: (current, total) => `Photo ${current} of ${total}`
    },
    tr: {
      title: "Arkadaş filtreleri", online: "Çevrimiçi", onlineHint: "Sadece çevrimiçi arkadaşları göster",
      favorites: "Favoriler", favoritesHint: "Sadece favorileri göster", favoritesLoaded: "Yüklenen favoriler",
      more: "100 arkadaş daha yükle", manual: "Diğer arkadaşlar sadece + düğmesine basınca yüklenir",
      nationality: "Ülke", all: "Tüm ülkeler", unknown: "Bilinmeyen ülke",
      countryCount: count => `${count} ülke`, ageRange: "Yaş", minAge: "En az", maxAge: "En çok",
      includeUnknownAge: "Bilinmeyen yaşları göster", ageHint: "Bazı profillerde yaş görünmez",
      search: "Ara", clear: "Aramayı temizle", reset: "Filtreleri sıfırla",
      loading: "Yükleniyor…", loaded: "Tüm arkadaşlar yüklendi", partial: "Yüklenen arkadaşlar",
      loadError: "Yükleme durdu. Tekrar denemek için Livu'yu yenileyin.", noMatches: "Eşleşme yok",
      count: (shown, total) => `${shown} / ${total}`,
      popupTitle: "Livu filtreleri", waiting: "Livu'da arkadaş listesini açın.", open: "Livu'yu aç",
      refresh: "Eklentiyi yükledikten veya güncelledikten sonra Livu'yu yenileyin.",
      session: "Tercihler kaydedilemedi.",
      statusOnline: "Çevrimiçi", statusUnavailable: "Uygun değil", statusOffline: "Çevrimdışı",
      statusUnknown: "Durum bilinmiyor", statusHint: "Livu'dan alınan durum; liste açıkken yenilenir",
      openProfile: "Profili aç", profileWaiting: "Profil bağlantısı henüz hazır değil",
      copyLink: "Profil bağlantısını kopyala", copied: "Bağlantı kopyalandı", videoCall: "Görüntülü ara", message: "Mesaj",
      addFavorite: "Favorilere ekle", removeFavorite: "Favorilerden kaldır", rename: "Adı değiştir",
      addContact: "Kişilere ekle", inContacts: "✓ Kişilerde", savingContact: "Kaydediliyor…", contactSaved: "Kişi kaydedildi. Notion bağlıysa eşitlenir.",
      pinPerson: "Kişiyi sabitle", unpinPerson: "Kişi sabitlemesini kaldır", pinConversation: "Sohbeti sabitle", unpinConversation: "Sohbet sabitlemesini kaldır",
      save: "Kaydet", cancel: "İptal", close: "Kapat", pin: "Kenar çubuğunu açık tut", unpin: "Sabitlemeyi kaldır",
      actionFailed: "İşlem tamamlanamadı", unavailable: "Bu işlem henüz kullanılamıyor",
      profileLoading: "Profil yükleniyor…", profileUnavailable: "Diğer bilgiler için profili açın",
      saved: "Kaydedildi", copyManually: "Bu bağlantı artık kullanılamıyor", renameUnavailable: "Bu kişi artık kullanılamıyor", age: "Yaş",
      photos: "Profil fotoğrafları", previousPhoto: "Önceki fotoğraf", nextPhoto: "Sonraki fotoğraf",
      photosLoading: "Fotoğraflar yükleniyor…", photosUnavailable: "Fotoğraflar için profili açın",
      photoCount: (current, total) => `Fotoğraf ${current} / ${total}`
    }
  };

  function translations(language) {
    return TRANSLATIONS[String(language).toLowerCase().startsWith("tr") ? "tr" : "en"];
  }

  globalThis.LivuFriendFiltersCore = Object.freeze({
    STORAGE_KEY, DEFAULTS, normalizeSettings, readFriend, readAge, validAge, ageFromBirthday, readOnline, matchesFriend,
    countryLabel, compareCountries, searchKey, translations
  });
})();
