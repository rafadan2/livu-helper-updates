Version 2.1.11 removes automatic password prompts, reuses the Contacts Notion connection for Autofill unless disconnected, and shows the private account list’s **Gift test** status in Autofill cards and email suggestions. Refresh coins to update recorded gift status.

Version 2.1.10 added **Select top 5** before **Select top 20**, using the same search, sort, Online only filter and greeting eligibility rules.

 LivU Helper · 2.1.11

Version 2.1.9 adds a simple **+** to the compact hover toolbar in Chrome and Safari, including the small conversation avatars. It saves the hovered person's name, profile link and available country without opening the profile or contacts page. Both Add controls share saving/saved state, preventing repeat clicks while saving. Android retains 2.1.8 functionality.

Version 2.1.8 fixes Android email Autofill excluding accounts without saved passwords and recognizes normalized native login hints. Password-only forms still require a password. Contacts now offers **Open LivU & copy ID**, using the actual app launcher, separately from **Web profile**. Direct native profile navigation remains unsupported until a working native Share route is verified. Chrome and Safari keep 2.1.7 functionality. Host tests and APK signing/build checks pass; phone behavior remains unverified.

Version 2.1.7 syncs contact Country through the existing private Notion contacts list. Chrome and Safari capture available country names when saving profiles or hover cards, show them on saved cards, and support country search and editing. Viewing or hovering an existing contact fills a missing country while keeping saved nicknames and notes. Known countries are kept until edited manually or refreshed from Notion. Android reads, displays and searches the same country field on its next contacts refresh. Older contacts without country remain supported; no country is guessed or fetched in bulk.

Version 2.1.6 adds Add/Delete contact to the small conversation-avatar popup and Delete to saved contact cards. Deletion requires confirmation and syncs to Notion; it does not remove a LivU friendship. Rename keeps the draft open while native rows refresh or are replaced, and cancels on an actual account switch. Browser Autofill fills the email even when Notion Password is empty or unavailable and explains why the password was skipped. Android retains the existing feature set and reads contact deletions on refresh.

Version 2.1.5 launches external Android profile activities in the destination app's task, so they do not remain under the Helper's icon in Recents. Native LivU profile navigation is still unverified; this change does not fix unsupported profile links. Chrome and Safari retain the functionality of 2.1.4.

Chrome and Safari are built from one maintained source. Android uses the same release and private Notion list identifiers. Making a release produces all three packages together.

Version 2.1.4 uses the selected account’s **Password** text field in private Notion. Choose an account and press LivU’s Next; the password fills automatically, without a password prompt or a second account selection. Browser passwords are fetched on selection, remain only in tab memory for the one-use fill (up to two minutes), and never enter saved account lists or backups. Missing/empty passwords leave the email filled and show a notice without a shared-password fallback. Offline metadata lists can still use a manually entered tab password. Android sync stores per-account Notion passwords in its existing encrypted vault. Editing the email, forgetting the password or changing the connection cancels the pending fill; existing passwords and signup/verification screens are left alone. Sign in remains your action.

**Helper updates** is available in this version. Install this version manually once. Android Settings provides Check → Download → Install with system approval; Safari Contacts/Autofill and the Chrome popup provide update checks and download links. The separate code-only update channel is published at `https://github.com/rafadan2/livu-helper-updates`. Package sizes, hashes and the Chrome update broker are checked as part of release verification. Checks do not use Notion tokens or send private records.

Version 2.0.3 accepts date-only Notion account Updated values while keeping snapshot timestamps timezone-qualified. Browser contact checks and online status now decode LivU's share-link number into the native user ID; saved links stay unchanged. These fixes have regression coverage; live server results still require checking after the installed extension is reloaded.

## What is shared

| Feature | Chrome | Safari | Android APK |
| --- | --- | --- | --- |
| Accounts and recorded coins from private Notion | Yes | Yes | Yes |
| Password from private Notion | On selection, memory only | On selection, memory only | On sync, encrypted vault |
| Choose an account and fill login fields | LivU webpage | LivU webpage | Native LivU Autofill |
| Shared contacts, search and open profile | Yes | Yes | Yes |
| Contact country from Notion, display and search | Yes, editable | Yes, editable | Yes, read-only |
| Save a profile with the floating + or hover-card Add to contacts | Yes | Yes | Read-only contacts |
| Selected-contact selam, online filter, select all/top 5/top 20 | Yes | Yes | Use a browser helper |
| Friend filters, pins, row tools and copy-only call phrases | Yes | Where LivU renders these controls | Use a browser helper |

Android cannot put the browser controls over native LivU. Its Contacts screen can launch LivU and copy a profile ID or open the web profile separately. It does not automatically navigate to native profiles. Copy link remains available.

## Install or update

- **Chrome:** extract `LivU-Chrome-Helper.zip`. Replace the files in the original installed extension folder, click **Reload** at `chrome://extensions`, then reload LivU. Its new name is **LivU Helper**. For first installation, enable Developer mode and use **Load unpacked** to select the folder containing `manifest.json`. Keep the original folder/extension entry to preserve local settings; avoid duplicate copies.
- **Safari:** replace `LivU Contacts.user.js` in the existing Userscripts folder and reload LivU. Its name, namespace and storage keys are preserved. Enable Userscripts and allow LivU if needed. Contacts shows version **2.1.11**. The email-field account picker and **Autofill** button appear on the webpage; Safari's system Passwords menu is separate.
- **Android:** install `LivU-Helper-2.1.11.apk` over the existing helper in the same Android profile/Secure Folder. Do not uninstall first. Packaging checks its certificate against the previous APK. Saved passwords, connections and account selection remain in the encrypted vault.

For later releases, Android verifies the downloaded APK's hash, size, package, version and signing certificate before offering the installer. If prompted, allow LivU Helper to install apps in that same Android profile, return and tap Install again. Safari's Userscripts menu can show **Available Updates** from the script's version metadata; approve there or use **Open Safari update** and its install prompt. Keep one script copy. The current unpacked Chrome installation still needs file replacement and **Reload** at `chrome://extensions`, followed by reloading LivU; the helper cannot silently replace an unpacked extension.

## Data sync and refresh

All three use the existing private **LivU Accounts** and **LivU Contacts** lists. No replacement pages are created. Save a connection on each device with access to the appropriate lists. Browser contacts need read/insert/update access; Android only reads. Browser Autofill → Account setup & sync → **Use contacts connection** reuses your saved Contacts key after validating account access. Android Contacts → **Use account connection** reuses the saved integration if it also has Contacts access.

Browser account refresh reads only enabled, created accounts instead of the whole signup queue. It shows progress and keeps cached account choices usable during the download. Initial connection errors are shown even when no key has been saved yet. Hover-card **Add to contacts** saves the hovered person's name and profile link without opening another page; existing nicknames and notes are preserved.

If a Notion account has an empty Email, refresh loads the other valid accounts and lists the unavailable account numbers. Fill Email in Notion and refresh to restore them. No email is guessed from another field. The APK retains locally saved passwords for unavailable rows but excludes them from Autofill. Malformed values and duplicate identities still stop the refresh and keep the previous cache.

| Data | When it refreshes |
| --- | --- |
| Browser contacts | Opening Contacts, manual sync, connecting, or saving/editing |
| Browser accounts/coins | Opening Autofill, connecting, or Refresh coins |
| Browser account password | Each explicit account selection; never persisted in the metadata cache |
| Android accounts | When the account list becomes visible, or Settings → Sync now |
| Android contacts | When Contacts becomes visible, after connecting, or Refresh |
| Browser contact online status | Opening Contacts or Refresh status; expires after two minutes |
| Native friend Online filter | Uses the shared friend adapter while its list is visible |

Saved lists work offline; failed refreshes keep previous data. Connection panels show the latest result and refresh time. Coins are ledger/Notion snapshots, not live balances. Desktop metadata sync must run after ledger updates for those changes to reach Notion; this release does not change its schedule.

Contacts and account metadata sync through Notion. The Password text field supplies account passwords: browser helpers fetch it on selection without saving it in metadata/backups, while Android sync keeps it in the encrypted vault. Integration tokens, filters, pins and greeting/approval history stay on each device. A complete Notion refresh removes clean browser copies of deleted contacts; pending local edits take priority. Offline deletions remain queued until sync succeeds. Avoid simultaneous edits to one contact on multiple devices.

Greetings keep sender checks, draft/call protection and uncertain-result safeguards. One approval covers only the checked contacts and the displayed maximum cost. Free chats add no coins, paid chats add 9 each, and previously greeted contacts are excluded before approval. Selection and filters do not send messages.

If a contact check fails, the remaining greetings pause before further requests. Failed contact and online checks show HTTP/LivU codes and, when available, whether the outgoing contact parameter and account matched. These comparisons expose no IDs or session secrets. An HTTP 400 alone does not establish whether the cause is the helper, the session or LivU's server; live verification is still needed for the reported failure.

## Maintain and release

- `contacts.js`: contacts, account picker, sync, presence and greetings.
- `friends/`: shared filters, page adapters, row tools, pins, phrases and Chrome popup.
- `platforms/`: browser adapters and Chrome manifest template.
- `release.json`: version, Android version code, Notion version and list identifiers.
- `../android-helper/`: Android UI, encrypted vault and platform Autofill.

Edit these sources rather than generated browser files. From the project root:

```powershell
node helper-shared/scripts/build.cjs
./helper-shared/scripts/release.ps1
```

The first command generates Chrome, Safari and Android's contract. The second builds the APK, checks its signing identity and packages the three updates, guide and checksums in `helper-data`. A missing previous signing identity is an error, not permission to replace an installed app's key.

For GitHub, use `./helper-shared/scripts/release.ps1 -ForGitHub`. This builds clean packages in `downloads/` without reading or including the private account snapshot. It also stages `downloads/update-channel/` with the signed APK, clean Chrome ZIP, Safari script/metadata and `update.json` with exact sizes and SHA-256 hashes. Only named artifacts enter that folder; publishing it to the separate update repository is a separate step. Personal packages in `helper-data/` are not changed. GitHub downloads require your existing private Notion connection or a separately transferred metadata export. On a fresh clone, pass `-SigningReference ./downloads/LivU-Helper-2.0.0.apk`; keep the original signing key outside the repository.

Run the shared browser checks, five Safari/core suites and Android vault/Autofill/metadata checks before releasing. Local previews use dummy data. Build/host checks cannot verify Safari, Samsung Autofill or native profile links on a phone.
