(() => {
  "use strict";
  if (globalThis.__livuRowTools) return;
  globalThis.__livuRowTools = true;
  const Core = globalThis.LivuFriendFiltersCore;
  const t = Core.translations(document.documentElement.lang || "en");
  const PIN_STORAGE_KEY = "livuFriendFilterPins";
  let settings = { ...Core.DEFAULTS };
  let activeRow, hoverTimer, closeTimer, updateTimer, renameDetachTimer;
  let renameSequence = 0;
  let renameSession = null;
  let contactSave = null;
  const gallery = { id: null, photos: [], index: 0, state: "idle", failed: null };
  const pins = new Map();
  const savedOrders = new WeakMap();
  let pinStore = { version: 1, accounts: {} };
  let pinAccount = "default";
  let pinnedPeople = new Set();
  let pinnedConversations = new Set();
  const scrolls = { friend: 0, message: 0 };
  let restore = null;
  const icons = {
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M15 5V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1"/>',
    call: '<rect x="3" y="5" width="12" height="14" rx="3"/><path d="m15 9 6-3v12l-6-3z"/>',
    favorite: '<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.4-5.7-3-5.7 3 1.1-6.4L2.8 9.7l6.4-.9z"/>',
    rename: '<path d="m15 4 5 5M4 20l4-1L20 7a2 2 0 0 0-4-4L4 15z"/>',
    message: '<path d="M20 11a8 8 0 0 1-12 7l-5 2 2-5A8 8 0 1 1 20 11z"/>',
    pin: '<path d="m8 3 8 0-1 7 4 4H5l4-4zM12 14v7"/>',
    profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    previous: '<path d="m15 5-7 7 7 7"/>', next: '<path d="m9 5 7 7-7 7"/>'
  };
  const svg = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]}</svg>`;
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(`
    :host{font:12px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:#252033;color-scheme:light}
    *{box-sizing:border-box}button,input{font:inherit}button{border:0;cursor:pointer;background:none;color:inherit}
    button:disabled{opacity:.38;cursor:default}button:focus-visible,input:focus-visible{outline:2px solid #9254ff;outline-offset:2px}
    svg{width:17px;height:17px;flex:none}.actions{display:flex;gap:2px;padding:3px;background:white;border:1px solid #ece7f1;border-radius:9px;box-shadow:0 3px 14px #30204316}
    .icon{display:grid;place-items:center;width:28px;height:28px;padding:5px;border-radius:6px;color:#81768b}
    .icon:hover:enabled{background:#f3edff;color:#7b2cff}.icon[aria-pressed=true]{color:#8a30ed}.icon[aria-pressed=true] svg{fill:#8a30ed}
    .card{width:260px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);display:flex;flex-direction:column;background:white;border:1px solid #e9e0f2;border-radius:16px;box-shadow:0 12px 44px #3520472a;overflow:hidden}
    .cover{height:min(160px,35dvh);flex:none;min-height:0;position:relative;display:grid;place-items:center;overflow:hidden;background:linear-gradient(135deg,#eadfff,#f9eef5)}
    .cover img{position:absolute;inset:0;display:block;width:100%;height:100%;min-width:0;min-height:0;object-fit:cover}.initial{font-size:56px;font-weight:600;color:#a77bd3}
    .close{position:absolute;top:9px;right:9px;border-radius:50%;width:25px;height:25px;background:#fffe;color:#776382;font-size:19px;line-height:1}
    .photo-nav{position:absolute;top:50%;transform:translateY(-50%);display:grid;place-items:center;width:28px;height:34px;border-radius:9px;background:#25143388;color:white;opacity:0;pointer-events:none}
    .photo-nav:hover{background:#251433b8}.photo-prev{left:9px}.photo-next{right:9px}.cover:hover .photo-nav,.cover:focus-within .photo-nav{opacity:1;pointer-events:auto}
    .photo-count{position:absolute;bottom:9px;right:9px;padding:3px 7px;border-radius:20px;background:#25143388;color:white;font-size:10px;font-variant-numeric:tabular-nums;line-height:1.4}
    .body{padding:13px 14px 14px;min-height:0;overflow:auto;overscroll-behavior:contain;scrollbar-width:thin}.name{margin:0;font-size:16px;font-weight:650;overflow-wrap:anywhere}.meta{margin-top:4px;display:flex;gap:7px;align-items:center;color:#9987a7;font-size:11px;flex-wrap:wrap}
    .status::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;background:#aaa1b2;margin-right:4px}
    .status[data-online=true]::before{background:#11de02}.bio{margin:9px 0 0;color:#8b7d94;max-height:86px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere}
    .card .actions{box-shadow:none;border:0;padding:9px 0 0;gap:4px;justify-content:space-between}.card .icon{width:35px;height:32px;background:#f5f2f8;border-radius:8px}
    .open{margin-top:12px;color:#8a30ed;width:100%;padding:7px;border-radius:8px;background:#f2ebff;font-weight:600}
    .add-contact{margin-top:10px;width:100%;padding:8px;border-radius:8px;background:#8a30ed;color:white;font-weight:600}
    .notice{margin:8px 0 0;font-size:11px;color:#a292af;overflow-wrap:anywhere}.rename-box{margin-top:10px;display:grid;grid-template-columns:1fr auto;gap:7px}
    input{width:100%;min-width:0;border:1px solid #e6daee;border-radius:7px;padding:7px;color:#4c3c59;background:#faf8fc}
    .save{color:#8a30ed;font-weight:600}.cancel{grid-column:1/-1;justify-self:end;color:#a08caa;font-size:11px;padding:0}
    .pin{color:#a396ae;width:25px;height:25px;padding:4px;display:grid;place-items:center;border-radius:6px}.pin[aria-pressed=true]{color:#8a30ed;background:#f2ebff}
    [hidden]{display:none!important}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto}}
  `);
  function host(tag) {
    const element = document.createElement(tag);
    const shadow = element.attachShadow({ mode: "open" }); shadow.adoptedStyleSheets = [sheet];
    return element;
  }
  const toolbar = host("livu-row-actions"), preview = host("livu-profile-preview");
  toolbar.hidden = preview.hidden = true;
  const buttons = () => ["copy", "call", "favorite", "rename", "message", "pin"].map(name => `<button class="icon" type="button" data-action="${name}" title="" aria-label="">${svg(name === "pin" ? "pin" : name)}</button>`).join("");
  toolbar.shadowRoot.innerHTML = `<div class="actions" role="toolbar"></div>`;
  toolbar.shadowRoot.querySelector(".actions").innerHTML = buttons();
  preview.shadowRoot.innerHTML = `<section class="card" role="dialog" aria-modal="false">
    <div class="cover" tabindex="0" role="group"><img alt="" decoding="async" hidden><span class="initial"></span><button class="close" type="button">×</button>
    <button class="photo-nav photo-prev" type="button" data-photo-step="-1" hidden>${svg("previous")}</button><button class="photo-nav photo-next" type="button" data-photo-step="1" hidden>${svg("next")}</button><span class="photo-count" role="status" aria-live="polite" hidden></span></div>
    <div class="body"><h2 class="name"></h2><div class="meta"><span class="country"></span><span class="status"></span><span class="age" hidden></span></div>
    <p class="bio" hidden></p><div class="actions" role="toolbar">${buttons()}</div>
    <div class="rename-box" hidden><input id="rename-input" data-action="rename-save" type="text" maxlength="30" spellcheck="false" autocomplete="off"><button id="rename-save" data-action="rename-save" class="save" type="button"></button><button class="cancel" type="button"></button></div>
    <button class="add-contact" type="button" data-action="add-contact" disabled></button><button class="delete-contact open" type="button" data-action="delete-contact" hidden>Delete contact</button><p class="contact-notice notice" role="status" aria-live="polite" hidden></p>
    <button class="open" type="button" data-action="profile"></button><p class="notice action-notice" role="status"></p><input class="copy-manually" readonly hidden></div></section>`;
  const contactButton = preview.shadowRoot.querySelector('.add-contact');
  const contactNotice = preview.shadowRoot.querySelector('.contact-notice');
  const deleteButton = preview.shadowRoot.querySelector('.delete-contact');
  contactButton.textContent = t.addContact;
  function contactTarget() {
    if (!activeRow?.isConnected || !isVisible(activeRow) || preview.getAttribute('data-lff-target') !== rowId(activeRow)) return null;
    try {
      const data = JSON.parse(activeRow.getAttribute('data-lff-preview') || '{}');
      const api = globalThis.LivuContactActions;
      if (!api) return null;
      const item = api.capture({ id: rowId(activeRow), url: data.profileUrl,
        name: data.userName || activeRow.querySelector('.name')?.textContent,
        country: activeRow.querySelector('.country-name')?.textContent || data.country });
      return { api, item, id: rowId(activeRow), account: document.documentElement.getAttribute('data-lff-account-id') || '' };
    } catch { return null; }
  }
  function sameContact(target) {
    return target && activeRow?.isConnected && rowId(activeRow) === target.id &&
      (document.documentElement.getAttribute('data-lff-account-id') || '') === target.account;
  }
  function updateContactButton() {
    const target = contactTarget();
    const state = sameContact(contactSave) ? contactSave : null;
    const saved = Boolean(target && target.api.has(target.item.url));
    if (saved && target.item.country) target.api.observe({ ...target.item, id: target.id });
    contactButton.textContent = state?.pending ? t.savingContact : saved ? t.inContacts : t.addContact;
    contactButton.disabled = !target || saved || Boolean(state?.pending) || !target.api.available();
    contactButton.title = !target ? t.profileWaiting : saved ? t.inContacts : t.addContact;
    deleteButton.hidden = !saved;
    deleteButton.disabled = !target || Boolean(state?.pending) || !target.api.available();
    contactNotice.textContent = state?.message || '';
    contactNotice.hidden = !state?.message;
  }
  contactButton.addEventListener('click', async event => {
    event.preventDefault(); event.stopPropagation();
    if (!event.isTrusted || contactButton.disabled) return;
    const target = contactTarget();
    if (!target) return;
    const attempt = { ...target, pending: true, message: '' };
    contactSave = attempt; updateContactButton();
    try {
      const result = await target.api.add({ id: target.id, url: target.item.url, name: target.item.name, country: target.item.country }, event);
      attempt.message = result.created ? t.contactSaved : t.inContacts;
    } catch (error) { attempt.message = error.message || t.actionFailed; }
    finally {
      attempt.pending = false;
      if (contactSave === attempt && sameContact(attempt)) { updateContactButton(); position(); }
    }
  });
  deleteButton.addEventListener('click', async event => {
    event.preventDefault(); event.stopPropagation();
    if (!event.isTrusted || deleteButton.disabled) return;
    const target = contactTarget();
    if (!target) return;
    try { await target.api.remove({ id: target.id, url: target.item.url, name: target.item.name }, event); }
    catch (error) { contactSave = { ...target, pending: false, message: error.message }; }
    if (sameContact(target)) { updateContactButton(); position(); }
  });
  document.addEventListener('livu-contacts-changed', updateContactButton);
  preview.shadowRoot.querySelector(".close").setAttribute("aria-label", t.close);
  preview.shadowRoot.querySelector(".close").addEventListener("click", hide);
  const cover = preview.shadowRoot.querySelector(".cover");
  cover.setAttribute("aria-label", t.photos);
  for (const button of cover.querySelectorAll("[data-photo-step]")) {
    button.title = Number(button.dataset.photoStep) < 0 ? t.previousPhoto : t.nextPhoto;
    button.setAttribute("aria-label", button.title);
    button.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); stepPhoto(Number(button.dataset.photoStep)); });
  }
  cover.addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key) || gallery.photos.length < 2) return;
    event.preventDefault(); event.stopPropagation(); stepPhoto(event.key === "ArrowLeft" ? -1 : 1);
  });
  cover.querySelector("img").addEventListener("error", () => { gallery.failed = cover.querySelector("img").getAttribute("src"); renderPhoto(); });
  preview.shadowRoot.querySelector('[data-action="profile"]').textContent = t.openProfile;
  preview.shadowRoot.querySelector(".save").textContent = t.save;
  preview.shadowRoot.querySelector(".cancel").textContent = t.cancel;
  const renameBox = preview.shadowRoot.querySelector(".rename-box");
  const renameInput = preview.shadowRoot.querySelector("#rename-input");
  const renameSave = preview.shadowRoot.querySelector("#rename-save");
  renameInput.setAttribute("aria-label", t.rename);
  preview.shadowRoot.querySelector(".cancel").addEventListener("click", event => {
    event.preventDefault(); event.stopPropagation(); cancelRename();
  });
  for (const element of [toolbar, preview]) {
    for (const button of element.shadowRoot.querySelectorAll("[data-action]")) {
      const action = button.dataset.action;
      const label = { copy: t.copyLink, call: t.videoCall, favorite: t.removeFavorite, rename: t.rename, message: t.message,
        pin: t.pinPerson }[action];
      if (label) { button.title = label; button.setAttribute("aria-label", label); }
    }
    element.addEventListener("pointerenter", () => { clearTimeout(closeTimer); clearTimeout(hoverTimer); });
    element.addEventListener("pointerleave", () => {
      if (renameOpen()) { clearTimeout(closeTimer); return; }
      clearTimeout(closeTimer); closeTimer = setTimeout(hide, 350);
    });
    element.addEventListener("click", event => {
      const button = event.composedPath()[0]?.closest?.("[data-action]");
      if (button?.dataset.action === "pin" && !button.disabled && activeRow && event.isTrusted) {
        event.preventDefault(); event.stopPropagation(); togglePin(activeRow); return;
      }
      if (button?.dataset.action !== "rename") return;
      if (!event.isTrusted || button.disabled || !activeRow) return;
      event.preventDefault(); event.stopPropagation(); beginRename(activeRow);
    });
  }
  function rowId(row) { return row?.getAttribute("data-id") || row?.getAttribute("data-lff-user-id"); }
  function rowKind(row) { return row?.closest(".im-list") ? "conversation" : "person"; }
  function renameOpen() { return Boolean(renameSession && !renameBox.hidden); }
  function renameIdentity(row, session = renameSession) {
    return Boolean(session && row?.isConnected && rowId(row) === session.id && rowKind(row) === session.kind &&
      (document.documentElement.getAttribute("data-lff-account-id") || "") === session.account);
  }
  function renameRows(session = renameSession) {
    if (!session) return [];
    const selector = session.kind === "conversation" ? ".im-list .ocell.user-cell" : ".friend-list .ocell";
    return Array.from(document.querySelectorAll(selector)).filter(row => rowId(row) === session.id &&
      rowKind(row) === session.kind && !row.closest(".im-block, .im-say-hi"));
  }
  function setRenameIdentity(session, valid) {
    preview.setAttribute("data-lff-rename-active", "true");
    preview.setAttribute("data-lff-rename-id", session.id);
    preview.setAttribute("data-lff-rename-kind", session.kind);
    preview.setAttribute("data-lff-rename-account", session.account);
    preview.setAttribute("data-lff-rename-token", session.token);
    preview.setAttribute("data-lff-rename-valid", String(Boolean(valid)));
    preview.setAttribute("data-lff-target", session.id);
    toolbar.setAttribute("data-lff-target", session.id);
    renameSave.disabled = !valid;
  }
  function clearRenameIdentity() {
    clearTimeout(renameDetachTimer); renameDetachTimer = null;
    for (const key of ["data-lff-rename-active", "data-lff-rename-id", "data-lff-rename-kind", "data-lff-rename-account", "data-lff-rename-token", "data-lff-rename-valid"]) {
      preview.removeAttribute(key);
    }
    renameSave.disabled = false;
    renameSession = null;
  }
  function cancelRename() {
    clearRenameIdentity();
    renameBox.hidden = true;
  }
  function beginRename(row) {
    const id = rowId(row);
    if (!row?.isConnected || !/^[1-9]\d{0,15}$/.test(id || "")) return;
    clearTimeout(hoverTimer); clearTimeout(closeTimer);
    clearRenameIdentity();
    const inputValue = row.querySelector(".name")?.textContent.trim() || "";
    renameSession = { id, kind: rowKind(row), account: document.documentElement.getAttribute("data-lff-account-id") || "",
      token: `${Date.now().toString(36)}-${++renameSequence}`, valid: true };
    setRenameIdentity(renameSession, true);
    renameBox.hidden = false; renameInput.value = inputValue;
    preview.hidden = false; position(); renameInput.focus(); renameInput.select();
  }
  function preserveRenameOnMissingRow() {
    if (!renameOpen()) return false;
    activeRow = null; toolbar.hidden = true; preview.hidden = false;
    setRenameIdentity(renameSession, false);
    clearTimeout(renameDetachTimer);
    const token = renameSession.token;
    renameDetachTimer = setTimeout(() => {
      if (!renameSession || renameSession.token !== token) return;
      const replacement = renameRows().find(row => row.isConnected);
      if (replacement && renameIdentity(replacement)) {
        activeRow = replacement; setRenameIdentity(renameSession, true); refresh(); return;
      }
      renameSession.valid = false;
      preview.shadowRoot.querySelector(".action-notice").textContent = t.renameUnavailable;
      setRenameIdentity(renameSession, false);
    }, 300);
    return true;
  }
  function rebindRenameRow() {
    if (!renameOpen()) return false;
    if ((document.documentElement.getAttribute("data-lff-account-id") || "") !== renameSession.account) {
      hide(); return false;
    }
    const candidate = (activeRow && renameIdentity(activeRow) ? [activeRow] : [])
      .concat(renameRows().filter(row => row !== activeRow));
    const row = candidate.find(item => isVisible(item)) || candidate.find(item => item.isConnected);
    if (!row) return preserveRenameOnMissingRow();
    clearTimeout(renameDetachTimer); renameDetachTimer = null;
    activeRow = row; renameSession.valid = true;
    setRenameIdentity(renameSession, true);
    return true;
  }
  function cleanPinIds(values) {
    if (!Array.isArray(values)) return [];
    return [...new Set(values.filter(value => typeof value === "string" && /^[1-9]\d{0,15}$/.test(value)))].slice(0, 2000);
  }
  function normalizePinStore(value) {
    const accounts = {};
    const source = value && typeof value === "object" && value.accounts && typeof value.accounts === "object" ? value.accounts : {};
    for (const [key, record] of Object.entries(source)) {
      if (!/^(?:default|id:[1-9]\d{0,15})$/.test(key) || !record || typeof record !== "object") continue;
      accounts[key] = { people: cleanPinIds(record.people), conversations: cleanPinIds(record.conversations) };
    }
    return { version: 1, accounts };
  }
  function accountKey() {
    const id = document.documentElement.getAttribute("data-lff-account-id");
    return id && /^[1-9]\d{0,15}$/.test(id) ? `id:${id}` : "default";
  }
  function activatePinAccount() {
    const next = accountKey();
    if (next === pinAccount) return false;
    pinAccount = next;
    return true;
  }
  function loadPinSets() {
    const record = pinStore.accounts[pinAccount] || { people: [], conversations: [] };
    pinnedPeople = new Set(record.people);
    pinnedConversations = new Set(record.conversations);
  }
  function savePinSets() {
    pinStore = normalizePinStore(pinStore);
    pinStore.accounts[pinAccount] = { people: [...pinnedPeople], conversations: [...pinnedConversations] };
    return chrome.storage.local.set({ [PIN_STORAGE_KEY]: pinStore });
  }
  function restoreOrder(element) {
    const original = savedOrders.get(element);
    if (original) {
      const before = element.style.getPropertyValue("order");
      if (original.value) element.style.setProperty("order", original.value, original.priority);
      else element.style.removeProperty("order");
      savedOrders.delete(element);
      return before !== element.style.getPropertyValue("order");
    }
    return false;
  }
  function applyOrder(container, rowSelector, selected, sectioned = false) {
    const children = Array.from(container.children);
    const rows = children.filter(child => child.matches(rowSelector));
    const active = rows.some(row => selected.has(rowId(row)));
    if (!active) {
      let changed = container.hasAttribute("data-lff-pin-layout");
      container.removeAttribute("data-lff-pin-layout");
      for (const child of children) changed = restoreOrder(child) || changed;
      return changed;
    }
    container.setAttribute("data-lff-pin-layout", "true");
    let desired = [];
    if (sectioned) {
      for (let index = 0; index < children.length;) {
        const child = children[index];
        desired.push(child); index++;
        if (!child.matches(".sort-title")) continue;
        const block = [];
        while (index < children.length && !children[index].matches(".sort-title")) block.push(children[index++]);
        const blockRows = block.filter(item => item.matches(rowSelector));
        const sorted = [...blockRows.filter(row => selected.has(rowId(row))), ...blockRows.filter(row => !selected.has(rowId(row)))];
        let rowIndex = 0;
        for (const item of block) desired.push(item.matches(rowSelector) ? sorted[rowIndex++] : item);
      }
    } else {
      const sorted = [...rows.filter(row => selected.has(rowId(row))), ...rows.filter(row => !selected.has(rowId(row)))];
      let rowIndex = 0;
      for (const child of children) desired.push(child.matches(rowSelector) ? sorted[rowIndex++] : child);
    }
    if (!sectioned || desired.length !== children.length) {
      const sorted = [...rows.filter(row => selected.has(rowId(row))), ...rows.filter(row => !selected.has(rowId(row)))];
      let rowIndex = 0;
      desired = [];
      for (const child of children) desired.push(child.matches(rowSelector) ? sorted[rowIndex++] : child);
    }
    let changed = false;
    desired.forEach((child, index) => {
      if (!savedOrders.has(child)) savedOrders.set(child, { value: child.style.getPropertyValue("order"), priority: child.style.getPropertyPriority("order") });
      const value = String(index);
      if (child.style.getPropertyValue("order") !== value) { child.style.setProperty("order", value); changed = true; }
    });
    return changed;
  }
  function syncPinRows() {
    const scrollPositions = [];
    for (const element of document.querySelectorAll(".mb-nav-panel .friend-list .list-wrap, .mb-nav-panel .im-list, .im-online .friend-list")) {
      scrollPositions.push([element, element.scrollTop]);
    }
    let changed = false;
    for (const list of document.querySelectorAll(".mb-nav-panel .friend-list, .im-online .friend-list")) {
      const bell = Boolean(list.closest(".im-online"));
      const rows = Array.from(list.querySelectorAll(bell ? ":scope > .ocell" : ".flist-box .ocell"));
      for (const row of rows) {
        const pinned = pinnedPeople.has(rowId(row));
        row.toggleAttribute("data-lff-person-pinned", pinned);
        row.toggleAttribute("data-lff-pinned", pinned);
      }
      const container = bell ? list : list.querySelector(".flist-box");
      if (container) changed = applyOrder(container, ".ocell", pinnedPeople, !bell) || changed;
    }
    for (const list of document.querySelectorAll(".mb-nav-panel .im-list")) {
      const rows = Array.from(list.querySelectorAll(":scope > .ocell.user-cell"));
      for (const row of rows) {
        const pinned = pinnedConversations.has(rowId(row));
        row.toggleAttribute("data-lff-conversation-pinned", pinned);
        row.toggleAttribute("data-lff-pinned", pinned);
      }
      changed = applyOrder(list, ".ocell.user-cell", pinnedConversations) || changed;
    }
    if (changed) requestAnimationFrame(() => {
      for (const [element, top] of scrollPositions) if (element.isConnected && Math.abs(element.scrollTop - top) > 1) element.scrollTop = top;
    });
  }
  function togglePin(row) {
    if (row?.matches(".im-bar .cur-msg-list > li")) return;
    const id = rowId(row), kind = rowKind(row);
    if (!/^[1-9]\d{0,15}$/.test(id || "")) return;
    const set = kind === "conversation" ? pinnedConversations : pinnedPeople;
    if (set.has(id)) set.delete(id); else set.add(id);
    syncPinRows();
    if (activeRow === row) refresh();
    savePinSets().catch(() => {});
  }
  function isVisible(row) {
    if (!row?.isConnected) return false;
    const rect = row.getBoundingClientRect(), clip = row.closest(".list-wrap")?.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.bottom > Math.max(0, clip?.top ?? 0)
      && rect.top < Math.min(innerHeight, clip?.bottom ?? innerHeight);
  }
  function position() {
    if (renameOpen() && !renameIdentity(activeRow)) {
      if (!rebindRenameRow() || !activeRow) return;
    }
    if (!activeRow) { if (!renameOpen()) hide(); return; }
    if (!isVisible(activeRow)) {
      if (renameOpen()) { toolbar.hidden = true; return; }
      hide(); return;
    }
    if (renameOpen()) toolbar.hidden = false;
    const rect = activeRow.getBoundingClientRect();
    const toolbarWidth = toolbar.getBoundingClientRect().width || 180;
    const compact = activeRow.matches(".im-bar .cur-msg-list > li");
    const toolbarLeft = compact
      ? (rect.right + toolbarWidth + 18 <= innerWidth ? rect.right + 10 : rect.left - toolbarWidth - 10)
      : rect.right - toolbarWidth - 2;
    toolbar.style.left = `${Math.max(8, Math.min(innerWidth - toolbarWidth - 8, toolbarLeft))}px`;
    toolbar.style.top = `${Math.max(8, rect.bottom - 28)}px`;
    if (preview.hidden) return;
    const panelRect = activeRow.closest(".im-panel")?.getBoundingClientRect() || rect;
    const cardRect = preview.getBoundingClientRect();
    const left = panelRect.left >= cardRect.width + 18 ? panelRect.left - cardRect.width - 10 : panelRect.right + 10;
    const actualLeft = left + cardRect.width <= innerWidth - 8 ? left : Math.max(8, Math.min(innerWidth - cardRect.width - 8, rect.left - 10));
    preview.style.left = `${actualLeft}px`;
    preview.style.top = `${Math.max(8, Math.min(innerHeight - cardRect.height - 8, rect.top))}px`;
  }
  function photoURL(value) {
    if (typeof value !== "string" || !value.trim() || value.length > 1500) return null;
    try {
      const url = new URL(value, location.href);
      return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  }
  function updateGallery(data) {
    const previous = gallery.id === rowId(activeRow) ? gallery.photos[gallery.index] : null;
    const avatar = photoURL(data.headImg) || photoURL(activeRow.querySelector(".avatar-wrap img, .fitImg-box img")?.getAttribute("src"));
    gallery.id = rowId(activeRow);
    gallery.photos = [...new Set([avatar, ...(Array.isArray(data.photos) ? data.photos.slice(0, 100).map(photoURL) : [])].filter(Boolean))];
    gallery.index = Math.max(0, gallery.photos.indexOf(previous));
    gallery.state = data.photosState || "idle";
    renderPhoto();
  }
  function renderPhoto() {
    const root = preview.shadowRoot, image = root.querySelector(".cover img");
    const photo = gallery.photos[gallery.index], multiple = gallery.photos.length > 1;
    if (photo && image.getAttribute("src") !== photo) image.src = photo;
    if (!photo) image.removeAttribute("src");
    image.hidden = !photo || gallery.failed === photo;
    root.querySelector(".initial").hidden = !image.hidden;
    image.alt = `${root.querySelector(".name").textContent} · ${t.photoCount(gallery.index + 1, gallery.photos.length)}`;
    for (const button of root.querySelectorAll("[data-photo-step]")) button.hidden = !multiple;
    const count = root.querySelector(".photo-count");
    count.hidden = !multiple && !["loading", "unavailable"].includes(gallery.state);
    count.textContent = multiple ? `${gallery.index + 1} / ${gallery.photos.length}` : gallery.state === "loading" ? "…" : "?";
    count.title = multiple ? t.photoCount(gallery.index + 1, gallery.photos.length) : gallery.state === "loading" ? t.photosLoading : t.photosUnavailable;
    count.setAttribute("aria-label", count.title);
  }
  function stepPhoto(step) {
    if (!activeRow || gallery.photos.length < 2) return;
    gallery.index = (gallery.index + step + gallery.photos.length) % gallery.photos.length;
    renderPhoto();
  }
  function refresh() {
    if (activeRow?.matches(".im-bar .cur-msg-list > li") && rowId(activeRow) !== preview.getAttribute("data-lff-target")) return hide();
    if (renameOpen() && !renameIdentity(activeRow)) {
      if (!rebindRenameRow() || !activeRow) return;
    }
    if (!activeRow || (!isVisible(activeRow) && !renameOpen())) return hide();
    let data = {};
    try { data = JSON.parse(activeRow.getAttribute("data-lff-preview") || "{}"); } catch {}
    const name = data.userName || activeRow.querySelector(".name")?.textContent.trim() || "";
    const root = preview.shadowRoot;
    root.querySelector(".name").textContent = name;
    root.querySelector(".card").setAttribute("aria-label", name);
    root.querySelector(".initial").textContent = Array.from(name)[0] || "";
    updateGallery(data);
    root.querySelector(".country").textContent = activeRow.querySelector(".country-name")?.textContent.trim() || data.country || "";
    const online = Core.readOnline(activeRow);
    const rawStatus = activeRow.getAttribute("data-lff-status");
    const unavailable = rawStatus === "1" || activeRow.querySelector(".online-status")?.classList.contains("s-1");
    const offline = rawStatus === "0" || activeRow.querySelector(".online-status")?.classList.contains("s-0");
    root.querySelector(".status").textContent = online ? t.statusOnline : unavailable ? t.statusUnavailable : offline ? t.statusOffline : t.statusUnknown;
    root.querySelector(".status").dataset.online = String(online);
    const age = Number(data.age); root.querySelector(".age").hidden = Core.validAge(age) == null;
    root.querySelector(".age").textContent = `${t.age} ${age}`;
    const bio = data.description || data.introduce || data.signature || "";
    root.querySelector(".bio").textContent = bio; root.querySelector(".bio").hidden = !bio;
    const favorite = data.favorite ?? (activeRow.getAttribute("data-lff-favorite") === "true");
    const kind = rowKind(activeRow), id = rowId(activeRow);
    const pinned = kind === "conversation" ? pinnedConversations.has(id) : pinnedPeople.has(id);
    for (const element of [toolbar, preview]) {
      for (const action of ["favorite", "rename", "call"]) {
        const button = element.shadowRoot.querySelector(`[data-action=${action}]`);
        button.disabled = !data[`${action}Action`];
        if (action === "favorite") {
          button.setAttribute("aria-pressed", String(favorite));
          button.title = favorite ? t.removeFavorite : t.addFavorite; button.setAttribute("aria-label", button.title);
        }
      }
      const pinButton = element.shadowRoot.querySelector('[data-action="pin"]');
      pinButton.hidden = activeRow.matches(".im-bar .cur-msg-list > li") || !/^[1-9]\d{0,15}$/.test(id || "");
      pinButton.setAttribute("aria-pressed", String(pinned));
      const pinLabel = pinned
        ? (kind === "conversation" ? t.unpinConversation : t.unpinPerson)
        : (kind === "conversation" ? t.pinConversation : t.pinPerson);
      pinButton.title = pinLabel; pinButton.setAttribute("aria-label", pinLabel);
    }
    updateContactButton();
    if (!preview.hasAttribute("data-lff-result")) root.querySelector(".action-notice").textContent = data.state === "ready" ? ""
      : data.state === "unavailable" ? t.profileUnavailable : t.profileLoading;
    position();
  }
  function hide() {
    clearTimeout(hoverTimer); clearTimeout(closeTimer);
    toolbar.hidden = preview.hidden = true; activeRow = null;
    contactSave = null;
    cancelRename();
    preview.shadowRoot.querySelector(".copy-manually").hidden = true;
  }
  function hover(event) {
    if (!(event.target instanceof Element) || event.target.closest("livu-row-actions, livu-profile-preview")) return;
    const row = event.target.closest(".friend-list .ocell, .im-list .ocell.user-cell, .im-bar .cur-msg-list > li");
    if (!row || row.closest(".im-block, .im-say-hi") || !/^\d+$/.test(rowId(row) || "") || Number(rowId(row)) <= 0) {
      if (renameOpen()) { clearTimeout(hoverTimer); clearTimeout(closeTimer); return; }
      clearTimeout(hoverTimer); clearTimeout(closeTimer); closeTimer = setTimeout(hide, 350); return;
    }
    clearTimeout(closeTimer);
    if (renameOpen()) {
      if (renameIdentity(row)) {
        clearTimeout(renameDetachTimer); renameDetachTimer = null;
        activeRow = row; renameSession.valid = true; setRenameIdentity(renameSession, true);
        toolbar.setAttribute("data-lff-target", renameSession.id); preview.setAttribute("data-lff-target", renameSession.id);
        refresh();
      }
      return;
    }
    if (row === activeRow) return;
    hide(); activeRow = row;
    for (const element of [toolbar, preview]) {
      element.setAttribute("data-lff-target", rowId(row)); element.removeAttribute("data-lff-result"); element.removeAttribute("data-lff-link");
      if (!element.isConnected) document.body.append(element);
    }
    toolbar.hidden = false; refresh();
    hoverTimer = setTimeout(() => { if (activeRow === row && isVisible(row)) { preview.hidden = false; refresh(); } }, 400);
  }
  function observeResults(element) {
    new MutationObserver(() => {
      const state = element.getAttribute("data-lff-result");
      const renameState = element.getAttribute("data-lff-rename-result");
      if (renameState && element === preview && renameSession &&
          renameSession.token === element.getAttribute("data-lff-rename-token")) {
        if (renameState === "saved") cancelRename();
        element.removeAttribute("data-lff-rename-result");
      }
      if (state === "opened") return hide();
      const label = { copied: t.copied, saved: t.saved, error: t.actionFailed, unavailable: t.unavailable, loading: t.loading, copy: t.copyManually }[state];
      if (label) preview.shadowRoot.querySelector(".action-notice").textContent = label;
      if (state === "copy") {
        const input = preview.shadowRoot.querySelector(".copy-manually");
        input.value = element.getAttribute("data-lff-link") || ""; input.hidden = false;
        preview.hidden = false; position(); input.focus(); input.select();
      }
    }).observe(element, { attributes: true, attributeFilter: ["data-lff-result", "data-lff-rename-result"] });
  }
  observeResults(toolbar); observeResults(preview);
  function savePinned(pinned) {
    settings = Core.normalizeSettings({ ...settings, sidebarPinned: pinned }); applyPinned();
    chrome.storage.local.set({ [Core.STORAGE_KEY]: settings }).catch(() => {});
  }
  function applyPinned() {
    document.documentElement.setAttribute("data-lff-sidebar-pinned", String(settings.sidebarPinned));
    for (const pin of pins.values()) {
      const button = pin.shadowRoot.querySelector("button"); button.setAttribute("aria-pressed", String(settings.sidebarPinned));
      button.title = settings.sidebarPinned ? t.unpin : t.pin; button.setAttribute("aria-label", button.title);
    }
  }
  function reconcile() {
    updateTimer = null;
    if (activatePinAccount()) loadPinSets();
    for (const [panel, pin] of pins) if (!panel.isConnected) { pin.remove(); pins.delete(panel); }
    for (const panel of document.querySelectorAll(".mb-nav-panel")) {
      const header = panel.querySelector(".p-title, .mb-title"); if (!header) continue;
      let pin = pins.get(panel);
      if (!pin) {
        pin = host("livu-sidebar-pin");
        pin.shadowRoot.innerHTML = `<button class="pin" type="button" aria-pressed="true">${svg("pin")}</button>`;
        pin.shadowRoot.querySelector("button").addEventListener("click", event => { event.stopPropagation(); savePinned(!settings.sidebarPinned); });
        pins.set(panel, pin);
      }
      if (pin.parentElement !== header) header.append(pin);
    }
    applyPinned();
    syncPinRows();
    if (activeRow || renameOpen()) refresh();
    if (restore) {
      const list = document.querySelector(restore.kind === "friend" ? ".mb-nav-panel .friend-list .list-wrap" : ".mb-nav-panel .im-list");
      if (list) { list.scrollTop = restore.top; if (list.scrollTop >= restore.top || Date.now() > restore.until) restore = null; }
    }
  }
  function schedule() { if (updateTimer == null) updateTimer = setTimeout(reconcile, 90); }
  const observer = new MutationObserver(mutations => {
    if (mutations.some(m => m.target === document.documentElement && m.attributeName === "data-lff-account-id") &&
        (!renameOpen() || (document.documentElement.getAttribute("data-lff-account-id") || "") !== renameSession.account)) hide();
    if (mutations.some(m => m.target === document.documentElement && m.attributeName === "data-lff-call-active" &&
        document.documentElement.getAttribute("data-lff-call-active") === "true")) hide();
    if (mutations.some(m => m.attributeName === "data-lff-account-id" || m.type === "childList" && [...m.addedNodes, ...m.removedNodes].some(node => node.nodeType === 1 &&
        (node.matches(".mb-nav-panel, .friend-list, .im-list") || node.querySelector(".mb-nav-panel, .friend-list, .im-list"))))) schedule();
    if (mutations.some(m => m.type === "childList" && m.target.nodeType === 1 &&
        m.target.closest(".friend-list .flist-box, .im-list") &&
        [...m.addedNodes, ...m.removedNodes].some(node => node.nodeType === 1 &&
          (node.matches(".ocell") || node.querySelector(".ocell"))))) schedule();
    if (restore && mutations.some(m => m.type === "childList" && m.target.nodeType === 1 &&
        m.target.closest(".mb-nav-panel .friend-list, .mb-nav-panel .im-list"))) schedule();
    if (activeRow && mutations.some(m => m.target === activeRow || activeRow.contains(m.target))) refresh();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true,
    attributeFilter: ["data-lff-preview", "data-lff-hidden", "data-lff-account-id", "data-lff-call-active", "data-id", "data-lff-user-id", "class"] });
  document.addEventListener("pointerover", hover, true);
  document.addEventListener("focusin", hover, true);
  document.addEventListener("keydown", event => { if (event.key === "Escape" && !preview.hidden) { hide(); event.stopPropagation(); } }, true);
  document.addEventListener("scroll", event => {
    const target = event.target;
    if (target instanceof Element && target.matches(".mb-nav-panel .friend-list .list-wrap, .mb-nav-panel .im-list")) {
      scrolls[target.matches(".im-list") ? "message" : "friend"] = target.scrollTop;
    }
    if (renameOpen() && !activeRow) refresh();
    else if (activeRow) position();
  }, true);
  document.addEventListener("click", event => {
    if (!(event.target instanceof Element)) return;
    const clickedRow = event.target.closest(".ocell");
    if (renameOpen() && clickedRow &&
        (rowId(clickedRow) !== renameSession.id || rowKind(clickedRow) !== renameSession.kind)) {
      hide(); return;
    }
    const tab = event.target.closest(".mb-nav-panel .the-tab li");
    if (tab) {
      const kind = tab.querySelector(".icon-friend") ? "friend" : "message";
      restore = { kind, top: scrolls[kind], until: Date.now() + 15000 }; hide(); schedule();
    } else if (!event.composedPath().some(el => el === toolbar || el === preview) && !event.target.closest(".ocell")) hide();
  }, true);
  window.addEventListener("resize", () => { if (renameOpen() && !activeRow) refresh(); else if (activeRow) position(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[Core.STORAGE_KEY]) { settings = Core.normalizeSettings(changes[Core.STORAGE_KEY].newValue); applyPinned(); }
    if (area === "local" && changes[PIN_STORAGE_KEY]) {
      pinStore = normalizePinStore(changes[PIN_STORAGE_KEY].newValue);
      activatePinAccount(); loadPinSets(); syncPinRows(); if (activeRow || renameOpen()) refresh();
    }
  });
  chrome.storage.local.get(Core.STORAGE_KEY).then(value => { settings = Core.normalizeSettings(value[Core.STORAGE_KEY]); })
    .catch(() => {}).finally(reconcile);
  chrome.storage.local.get(PIN_STORAGE_KEY).then(value => {
    pinStore = normalizePinStore(value[PIN_STORAGE_KEY]); activatePinAccount(); loadPinSets(); syncPinRows();
  }).catch(() => {}).finally(() => { if (activeRow || renameOpen()) refresh(); });
})();
