(() => {
  "use strict";
  const Core = globalThis.LivuFriendFiltersCore;
  globalThis.LivuUpdates.mount(document.getElementById('helper-updates'), { platform: 'chrome', request: globalThis.LivuUpdates.chromeManifest });
  const language = chrome.i18n.getUILanguage();
  const t = Core.translations(language);
  const ui = Object.fromEntries(Object.entries({
    online: "online", favorites: "favorites", status: "status", notice: "notice", reset: "reset", open: "open",
    countryToggle: "country-toggle", countryLabel: "country-label", countryMenu: "country-menu",
    countryOptions: "country-options", allCountries: "all-countries", ageLabel: "age-label",
    minAge: "min-age", maxAge: "max-age", includeUnknown: "include-unknown"
  }).map(([key, id]) => [key, document.getElementById(id)]));
  let settings = { ...Core.DEFAULTS };
  let report = null;
  let statusRequest = 0;
  let choices = new Map();
  let choiceSignature = "";

  for (const [id, text] of Object.entries({
    title: 'LivU Helper', "online-label": t.online, "favorites-label": t.favorites,
    "age-label": t.ageRange, "include-unknown-label": t.includeUnknownAge
  })) document.getElementById(id).textContent = text;
  document.documentElement.lang = language;
  ui.countryToggle.setAttribute("aria-label", t.nationality);
  ui.allCountries.textContent = t.all;
  ui.minAge.setAttribute("aria-label", t.minAge);
  ui.maxAge.setAttribute("aria-label", t.maxAge);
  ui.includeUnknown.title = t.ageHint;
  ui.includeUnknown.setAttribute("aria-label", t.includeUnknownAge);
  ui.online.title = t.onlineHint;
  ui.online.setAttribute("aria-label", t.onlineHint);
  ui.favorites.title = t.favoritesHint;
  ui.favorites.setAttribute("aria-label", t.favoritesHint);
  ui.reset.title = t.reset;
  ui.reset.setAttribute("aria-label", t.reset);
  ui.open.title = t.open;
  ui.open.setAttribute("aria-label", t.open);

  function renderCountries() {
    choices = new Map((report?.countries || []).map(item => [item.key, item.label]));
    for (const key of settings.countries) if (!choices.has(key)) {
      choices.set(key, Core.countryLabel(key, language) || t.unknown);
    }
    const sorted = Array.from(choices, ([key, label]) => ({ key, label }))
      .sort((a, b) => Core.compareCountries(a, b, language));
    const signature = JSON.stringify(sorted);
    if (signature !== choiceSignature) {
      ui.countryOptions.replaceChildren(...sorted.map(item => {
        const button = document.createElement("button"), label = document.createElement("span"), check = document.createElement("span");
        button.type = "button"; button.dataset.country = item.key; button.setAttribute("aria-pressed", "false");
        label.textContent = item.label; check.className = "check"; check.setAttribute("aria-hidden", "true");
        button.append(label, check); return button;
      }));
      choiceSignature = signature;
    }
    const selected = new Set(settings.countries);
    for (const button of ui.countryOptions.querySelectorAll("button[data-country]")) {
      const isSelected = selected.has(button.dataset.country);
      button.setAttribute("aria-pressed", String(isSelected)); button.querySelector(".check").textContent = isSelected ? "✓" : "";
    }
    ui.countryLabel.textContent = settings.countries.length ? t.countryCount(settings.countries.length) : t.nationality;
    ui.countryToggle.title = settings.countries.length
      ? sorted.filter(item => selected.has(item.key)).map(item => item.label).join(", ") : t.all;
    ui.countryToggle.disabled = !report?.active && choices.size === 0;
    ui.allCountries.disabled = settings.countries.length === 0;
  }

  function render() {
    ui.online.setAttribute("aria-checked", String(settings.onlineOnly));
    ui.favorites.setAttribute("aria-checked", String(settings.favoritesOnly));
    ui.includeUnknown.setAttribute("aria-checked", String(settings.includeUnknownAge));
    // Keep an unfinished edit visible while another tab or the page updates
    // settings. The change event commits it; blur then reflects normalization.
    if (document.activeElement !== ui.minAge) ui.minAge.value = settings.ageMin ?? "";
    if (document.activeElement !== ui.maxAge) ui.maxAge.value = settings.ageMax ?? "";
    renderCountries();
    ui.status.textContent = report?.active ? t.count(report.shown, report.loaded) : t.waiting;
    ui.status.title = report?.loading === "loading" ? t.loading : report?.loading === "error" ? t.loadError
      : settings.favoritesOnly ? t.favoritesLoaded : report?.loading === "complete" ? t.loaded : t.manual;
  }

  function closeCountry(returnFocus = false) {
    ui.countryMenu.hidden = true;
    ui.countryToggle.setAttribute("aria-expanded", "false");
    if (returnFocus) ui.countryToggle.focus();
  }

  async function refreshStatus() {
    const request = ++statusRequest;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const next = tab?.id == null ? null : await chrome.tabs.sendMessage(tab.id, { type: "LFF_STATUS" });
      if (request !== statusRequest) return;
      report = next;
    } catch {
      if (request !== statusRequest) return;
      report = null;
    }
    render();
  }

  async function save(patch) {
    settings = Core.normalizeSettings({ ...settings, ...patch });
    render();
    try {
      await chrome.storage.local.set({ [Core.STORAGE_KEY]: settings });
      ui.notice.hidden = true;
      await refreshStatus();
    } catch {
      ui.notice.textContent = t.session;
      ui.notice.hidden = false;
    }
  }

  ui.online.addEventListener("click", () => save({ onlineOnly: !settings.onlineOnly }));
  ui.favorites.addEventListener("click", () => save({ favoritesOnly: !settings.favoritesOnly }));
  ui.includeUnknown.addEventListener("click", () => save({ includeUnknownAge: !settings.includeUnknownAge }));
  ui.minAge.addEventListener("change", () => save({ ageMin: ui.minAge.value === "" ? null : Number(ui.minAge.value) }));
  ui.maxAge.addEventListener("change", () => save({ ageMax: ui.maxAge.value === "" ? null : Number(ui.maxAge.value) }));
  ui.minAge.addEventListener("blur", () => { ui.minAge.value = settings.ageMin ?? ""; });
  ui.maxAge.addEventListener("blur", () => { ui.maxAge.value = settings.ageMax ?? ""; });
  ui.countryToggle.addEventListener("click", () => {
    ui.countryMenu.hidden = !ui.countryMenu.hidden;
    ui.countryToggle.setAttribute("aria-expanded", String(!ui.countryMenu.hidden));
    if (!ui.countryMenu.hidden) ui.countryOptions.querySelector("button")?.focus();
  });
  ui.countryOptions.addEventListener("click", event => {
    const button = event.target.closest("button[data-country]");
    if (!button) return;
    const selected = new Set(settings.countries);
    if (button.getAttribute("aria-pressed") === "true") selected.delete(button.dataset.country);
    else selected.add(button.dataset.country);
    save({ countries: [...selected] });
  });
  ui.allCountries.addEventListener("click", () => save({ countries: [] }));
  ui.reset.addEventListener("click", () => save({ ...Core.DEFAULTS }));
  document.addEventListener("pointerdown", event => {
    if (!event.composedPath().includes(ui.countryMenu) && !event.composedPath().includes(ui.countryToggle)) closeCountry();
  }, true);
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !ui.countryMenu.hidden) { event.preventDefault(); closeCountry(true); }
  }, true);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[Core.STORAGE_KEY]) {
      settings = Core.normalizeSettings(changes[Core.STORAGE_KEY].newValue);
      render();
      refreshStatus();
    }
  });

  chrome.storage.local.get(Core.STORAGE_KEY).then(result => {
    settings = Core.normalizeSettings(result[Core.STORAGE_KEY]);
  }).catch(() => {
    ui.notice.textContent = t.session;
    ui.notice.hidden = false;
  }).finally(() => { render(); refreshStatus(); });
})();
