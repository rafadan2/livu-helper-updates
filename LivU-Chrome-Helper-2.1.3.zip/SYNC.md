# LivU Helper · 2.1.3

Chrome and Safari are built from one maintained source. Android uses the same release and private Notion list identifiers. Making a release produces all three packages together.

Version 2.1.3 automatically fills the existing-account password step after you select an email and press Next. Enter your shared LivU password once per tab, or cancel to fill only the email. It remains in tab memory until reload/close and is never saved to storage or Notion. The automatic step expires after two minutes, is cancelled by editing the email, Forget password, unavailable accounts or signup/verification screens, and never overwrites an entered password or presses Sign in. The email dropdown retains account numbers and recorded coins; selected greetings retain one total-cost approval.

**Helper updates** is available in this version. Install this version manually once. Android Settings provides Check → Download → Install with system approval; Safari Contacts/Autofill and the Chrome popup provide update checks and download links. The separate code-only update channel is staged locally and **not published yet**. Checks show unavailable until publication; they do not use Notion tokens or send private records.

Version 2.0.3 accepts date-only Notion account Updated values while keeping snapshot timestamps timezone-qualified. Browser contact checks and online status now decode LivU's share-link number into the native user ID; saved links stay unchanged. These fixes have regression coverage; live server results still require checking after the installed extension is reloaded.

## What is shared

| Feature | Chrome | Safari | Android APK |
| --- | --- | --- | --- |
| Accounts and recorded coins from private Notion | Yes | Yes | Yes |
| Choose an account and fill login fields | LivU webpage | LivU webpage | Native LivU Autofill |
| Shared contacts, search and open profile | Yes | Yes | Yes |
| Save a profile with the floating + or hover-card Add to contacts | Yes | Yes | Read-only contacts |
| Selected-contact selam, online filter, select all/top 20 | Yes | Yes | Use a browser helper |
| Friend filters, pins, row tools and copy-only call phrases | Yes | Where LivU renders these controls | Use a browser helper |

Android cannot put the browser controls over native LivU. Its Contacts screen opens profile links using the currently signed-in account. Native profile links still need phone verification; Browser and Copy link are available.

## Install or update

- **Chrome:** extract `LivU-Chrome-Helper.zip`. Replace the files in the original installed extension folder, click **Reload** at `chrome://extensions`, then reload LivU. Its new name is **LivU Helper**. For first installation, enable Developer mode and use **Load unpacked** to select the folder containing `manifest.json`. Keep the original folder/extension entry to preserve local settings; avoid duplicate copies.
- **Safari:** replace `LivU Contacts.user.js` in the existing Userscripts folder and reload LivU. Its name, namespace and storage keys are preserved. Enable Userscripts and allow LivU if needed. Contacts shows version **2.1.3**. The email-field account picker and **Autofill** button appear on the webpage; Safari's system Passwords menu is separate.
- **Android:** install `LivU-Helper-2.1.3.apk` over the existing helper in the same Android profile/Secure Folder. Do not uninstall first. Packaging checks its certificate against the previous APK. Saved passwords, connections and account selection remain in the encrypted vault.

For later releases, Android verifies the downloaded APK's hash, size, package, version and signing certificate before offering the installer. If prompted, allow LivU Helper to install apps in that same Android profile, return and tap Install again. Safari's Userscripts menu can show **Available Updates** from the script's version metadata; approve there or use **Open Safari update** and its install prompt. Keep one script copy. The current unpacked Chrome installation still needs file replacement and **Reload** at `chrome://extensions`, followed by reloading LivU; the helper cannot silently replace an unpacked extension.

## Data sync and refresh

All three use the existing private **LivU Accounts** and **LivU Contacts** lists. No replacement pages are created. Save a connection on each device with access to the appropriate lists. Browser contacts need read/insert/update access; Android only reads. Browser Autofill → Account setup & sync → **Use contacts connection** reuses your saved Contacts key after validating account access. Android Contacts → **Use account connection** reuses the saved integration if it also has Contacts access.

Browser account refresh reads only enabled, created accounts instead of the whole signup queue. It shows progress and keeps cached account choices usable during the download. Initial connection errors are shown even when no key has been saved yet. Hover-card **Add to contacts** saves the hovered person's name and profile link without opening another page; existing nicknames and notes are preserved.

If a Notion account has an empty Email, refresh loads the other valid accounts and lists the unavailable account numbers. Fill Email in Notion and refresh to restore them. No email is guessed from another field. The APK retains locally saved passwords for unavailable rows but excludes them from Autofill. Malformed values and duplicate identities still stop the refresh and keep the previous cache.

| Data | When it refreshes |
| --- | --- |
| Browser contacts | Opening Contacts, manual sync, connecting, or saving/editing |
| Browser accounts/coins | Opening Autofill, connecting, or Refresh coins |
| Android accounts | When the account list becomes visible, or Settings → Sync now |
| Android contacts | When Contacts becomes visible, after connecting, or Refresh |
| Browser contact online status | Opening Contacts or Refresh status; expires after two minutes |
| Native friend Online filter | Uses the shared friend adapter while its list is visible |

Saved lists work offline; failed refreshes keep previous data. Connection panels show the latest result and refresh time. Coins are ledger/Notion snapshots, not live balances. Desktop metadata sync must run after ledger updates for those changes to reach Notion; this release does not change its schedule.

Contacts and account metadata sync through Notion. Passwords, integration tokens, filters, pins and greeting/approval history stay on each device. Notion contact deletion does not remove browser cached copies; pending local edits take priority. Avoid simultaneous edits to one contact on multiple devices.

Greetings keep sender checks, draft/call protection and uncertain-result safeguards. One approval covers only the checked contacts and the displayed maximum cost. Free chats add no coins, paid chats add 9 each, and previously greeted contacts are excluded before approval. Selection and filters do not send messages.

If a contact check fails, the remaining greetings pause before further requests. Failed contact and online checks show HTTP/LivU codes and, when available, whether the outgoing contact parameter and account matched. These comparisons expose no IDs or session secrets. An HTTP 400 alone does not establish whether the cause is the helper, the session or LivU's server; live verification is still needed for the reported failure.

## Maintain and release

- `contacts.js`: contacts, account picker, sync, presence and greetings.
- `friends/`: shared filters, page adapters, row tools, pins, phrases and Chrome popup.
- `platforms/`: browser adapters and Chrome manifest template.
- `release.json`: version, Android version code, Notion version and list identifiers.
- `../android-helper/`: Android UI, encrypted vault and platform Autofill.

Edit these sources rather than generated browser files. From the project root:

```powershell
node helper-shared/scripts/build.cjs
./helper-shared/scripts/release.ps1
```

The first command generates Chrome, Safari and Android's contract. The second builds the APK, checks its signing identity and packages the three updates, guide and checksums in `helper-data`. A missing previous signing identity is an error, not permission to replace an installed app's key.

For GitHub, use `./helper-shared/scripts/release.ps1 -ForGitHub`. This builds clean packages in `downloads/` without reading or including the private account snapshot. It also stages `downloads/update-channel/` with the signed APK, clean Chrome ZIP, Safari script/metadata and `update.json` with exact sizes and SHA-256 hashes. Only named artifacts enter that folder; publishing it to the separate update repository is a separate step. Personal packages in `helper-data/` are not changed. GitHub downloads require your existing private Notion connection or a separately transferred metadata export. On a fresh clone, pass `-SigningReference ./downloads/LivU-Helper-2.0.0.apk`; keep the original signing key outside the repository.

Run the shared browser checks, five Safari/core suites and Android vault/Autofill/metadata checks before releasing. Local previews use dummy data. Build/host checks cannot verify Safari, Samsung Autofill or native profile links on a phone.
